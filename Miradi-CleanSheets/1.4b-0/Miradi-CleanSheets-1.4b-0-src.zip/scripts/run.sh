#!/bin/sh
java -jar ../lib/csheets.jar