Modifications to CleanSheets by the Miradi team:

0. Added this README.Miradi.txt file
1. Renamed 'bin' directory to 'scripts'
2. Rearranged source code directories to be more eclipse-friendly
   - Renamed src to source
   - Moved res directories inside their respective source packages
