/**

Provides the controller of the CleanSheets application, and an entry-point
for command-line invocation. Also provides a listener for receiving notification
of events occuring in the application.

*/
package csheets;