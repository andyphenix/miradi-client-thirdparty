/**

Provides a customized JTable-based grid component with a row header,
and a number of other minor improvements.

*/
package csheets.ui.grid;