/** 

Provides support for user-specified and system-generated assertions.
A language for assertions in Jester is specified by means of an ANTLR grammar.

*/
package csheets.ext.assertion;