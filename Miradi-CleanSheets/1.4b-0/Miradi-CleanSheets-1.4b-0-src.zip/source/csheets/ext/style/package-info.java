/** 

Provides support for cell style, i.e. font, format, alignment, color and border.

*/
package csheets.ext.style;