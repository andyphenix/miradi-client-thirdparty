/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



/**
 * User: Administrator
 */
package com.jenkov.mrpersister;

import com.jenkov.mrpersister.impl.PersistenceConfigurationFactory;
import com.jenkov.mrpersister.impl.GenericDaoFactory;
import com.jenkov.mrpersister.impl.mapping.ObjectMappingFactory;
import com.jenkov.mrpersister.itf.IPersistenceConfiguration;
import com.jenkov.mrpersister.itf.IPersistenceConfigurationFactory;
import com.jenkov.mrpersister.itf.IGenericDaoFactory;
import com.jenkov.mrpersister.itf.mapping.IObjectMappingFactory;

/**
 * This class is the starting point of any Mr Persister action. It is here you access
 * the factories needed to use Mr. Persister. It should not be necessary to change
 * any of the factories, even though it is possible to do so.
 *
 * <br/><br/>
 * The factory you will be using the most is the generic dao factory available using
 * the <code>getGenericDaoFactory()</code> method. The <code>IGenericDao</code> instances created
 * by this factory is the preferred way of using Mr. Persister.
 *
 * <br/><br/>
 * Another way of accessing the Mr. Persister functions is to create a DAO class that
 * extends <code>com.jenkov.mrpersister.impl.AbstractDao</code>. This was the preferred
 * way of using Mr. Persister before v. 2.2.0. The <code>AbstractDao</code> subclass
 * will then have a lot of read / write methods available to it.
 *
 *
 * <br/><br/>
 * <u>Generic DAO example:</u><br/><br/><br/>
 * <code>
 * IGenericDao dao = MrPersister.getGenericDaoFactory().createDao(connection);<br/>
 * <br/>
 * Employee myEmployeeObject = (Employee) dao.readByPrimaryKey(Employee.class, new Integer(employeeId));<br/>
 * <br/>
 * dao.insert(myEmployeeObject); <br/>
 * dao.update(myEmployeeObject); <br/>
 * dao.delete(myEmployeeObject); <br/>
 * dao.closeConnection();<br/>
 * <br/>
 * </code>
 * <br/><br/>
 * This is all there is to it. No mapping files necessary, and no magic classes to extend (anymore).
 * Mr. Persister is capable of guessing most trivial object-to-database
 * mappings itself. If you are wondering how, you should read the user guide / getting started manual
 * for more information.
 *
 * <br/><br/>
 * There are of course a lot more methods available on the <code>IGenericDao</code> instance than
 * the ones shown here.
 *
 * @deprecated Use a PersistenceManager instance to obtain the factories instead. Note: PersistenceManager instances
 * should be reused throughout the application lifetime.
 */
public class MrPersister {

//    private static final Map configurations = new HashMap();

    private static IObjectMappingFactory            objectMappingFactory = new ObjectMappingFactory();
    private static IPersistenceConfigurationFactory configurationFactory = new PersistenceConfigurationFactory();
    private static IGenericDaoFactory               genericDaoFactory    = new GenericDaoFactory();

    /**
     * Returns the persistence configuration factory currently in use.
     * The persistence factory replaces the <code>MrPersister.createConfiguration()</code> methods.
     * @return  The persistence factory currently in use.
     */
    public static synchronized IPersistenceConfigurationFactory getConfigurationFactory(){
        return configurationFactory;
    }

    /**
     * Sets the persistence configuration factory to be used with Mr. Persister in the future.
     * The persistence factory replaces the <code>MrPersister.createConfiguration()</code> methods.
     * You should never have to change the persistence factory. Only do so if you know what you
     * are doing.
     * @param factory The persistence factory to use.
     */
    public static synchronized void setConfigurationFactory(IPersistenceConfigurationFactory factory){
        configurationFactory = factory;
    }


    /**
     * Returns the object method factory set for the Mr Persister API. This is by default set
     * the implementation that comes with Mr. Persister.
     * @return The object method factory set for the Mr. Persister API.
     */
    public synchronized static IObjectMappingFactory getObjectMappingFactory() {
        return objectMappingFactory;
    }

    /**
      * Sets the object method factory set for the Mr Persister API. This is by default set
      * the implementation that comes with Mr. Persister.
      * @param factory The object method factory to be used with the Mr. Persister API.
      */
    public synchronized static void setObjectMappingFactory(IObjectMappingFactory factory){
        objectMappingFactory = factory;
    }

    /**
     * Returns the generic dao factory currently used by Mr Persister.
     * @return The generic dao factory currently used by Mr Persister.
     */
    public synchronized static IGenericDaoFactory getGenericDaoFactory(){
        return genericDaoFactory;
    }

    /**
     * Sets the generic dao factory to be used with Mr Persister. Most likely
     * you will not need to change it.
     * @param factory The generic dao factory to be used with Mr. Persister.
     */
    public synchronized static void setGenericDaoFactory(IGenericDaoFactory factory){
        genericDaoFactory = factory;
    }



    /*====== Deprecated methods below ====== */


    /**
     * Creates a new <code>IPersistenceConfiguration</code>.
     * @return A new <code>IPersistenceConfiguration</code>.
     * @deprecated Use <code>getConfigurationFactory().createConfiguration()</code> instead.
     */
    public static IPersistenceConfiguration createConfiguration() {
        return getConfigurationFactory().createConfiguration();
    }


    /**
     * Returns the persistence configuration stored by the given key. If none is stored by
     * that key an empty persistence configuration is created and stored by that key
     * and then returned. You could use the .class object of an AbstractDao subclass for the
     * key, or any other key you may desire.
     * @param configurationKey The key to get the persistence configuration for.
     * @return The persistence configuration matching the given key.
     * @deprecated The responsiblity of caching persistence configurations has been moved to the
     *             persistence configuration factory. Use getConfigurationFactory().get()/store()
     *             instead.
     * @see    IPersistenceConfigurationFactory
     */
    public synchronized static IPersistenceConfiguration getConfiguration(Object configurationKey){
        IPersistenceConfiguration configuration = getConfigurationFactory().getConfiguration(configurationKey);
        if(configuration == null){
            configuration = getConfigurationFactory().createConfiguration();
            getConfigurationFactory().storeConfiguration(configurationKey, configuration);
        }
        return configuration;

        /*
        IPersistenceConfiguration configuration = (IPersistenceConfiguration) configurations.get(configurationKey);
        if(configuration == null){
            configuration = new PersistenceConfiguration();
            configurations.put(configurationKey, configuration);
        }
        return configuration;
        */
    }

    /**
     * Stores the given persistence configuration by the given key. You could use
     * the .class object of an AbstractDao subclass for the key, or any other key you may desire.
     * @param configurationKey The key to store the persistence configuration by.
     * @param configuration
    *  @deprecated The responsiblity of caching persistence configurations has been moved to the
     *             persistence configuration factory.
     * @see    IPersistenceConfigurationFactory     */
    public synchronized static void setConfiguration(Object configurationKey, IPersistenceConfiguration configuration){
        getConfigurationFactory().storeConfiguration(configurationKey, configuration);

        //configurations.put(configurationKey, configuration);
    }


    /**
     * Removes the <code>IPersistenceConfiguration</code> stored for the given configuration key.
     * Note that if you call the <code>getConfigurationOrFail(Object configurationKey)</code> after
     * removing a specific persistence configuration, a blank persistence configuration will
     * be created and returned. A null will not be returned.
     *
     * @param configurationKey The key of the persistence configuration to remove.
     * @deprecated The responsiblity of caching persistence configurations has been moved to the
     *             persistence configuration factory.
     * @see    IPersistenceConfigurationFactory
     */
    public synchronized static void removeConfiguration(Object configurationKey) {
        getConfigurationFactory().removeConfiguration(configurationKey);
       //configurations.remove(configurationKey);
    }




}
