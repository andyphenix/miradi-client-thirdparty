/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



package com.jenkov.mrpersister.jdbc;

import javax.sql.DataSource;
import java.util.*;


/**
 * This class is still experimental.
 *
 * @author Jakob Jenkov - Copyright 2005 Jenkov Development
 */
public class DataSourceFactory {

    private Map  configurationMap = new HashMap();
    private Map  dataSourceMap    = new HashMap();


    public DataSourceFactory(ResourceBundle resources){
        synchronized(this){
            DatabaseConfigurationParser parser = new DatabaseConfigurationParser();
            List configurations = parser.parse(resources);
            for (Iterator iterator = configurations.iterator(); iterator.hasNext();) {
                DatabaseConfiguration configuration = (DatabaseConfiguration) iterator.next();
                this.configurationMap.put(configuration.getConfigurationId(), configuration);
                DataSource dataSource = new SimpleDataSource(
                        configuration.getDriver(), configuration.getUrl(),
                        configuration.getUser(),   configuration.getPassword());

                this.dataSourceMap.put(configuration.getConfigurationId(), dataSource);
            }
        }
    }

    public synchronized DataSource getDataSource(String configurationId){
        return (DataSource) this.dataSourceMap.get(configurationId);
    }


    public static DataSourceFactory createDataSourceFactory(ResourceBundle resources){
        if(resources == null){
            throw new NullPointerException("Error creating DataSourceFactory. The resource bundle supplied was null.");
        }
        return new DataSourceFactory(resources);
    }






}
