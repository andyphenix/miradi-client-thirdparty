/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



package com.jenkov.mrpersister;

import com.jenkov.mrpersister.impl.GenericDaoFactory;
import com.jenkov.mrpersister.impl.PersistenceConfigurationFactory;
import com.jenkov.mrpersister.impl.mapping.ObjectMappingFactory;
import com.jenkov.mrpersister.itf.IGenericDaoFactory;
import com.jenkov.mrpersister.itf.IPersistenceConfigurationFactory;
import com.jenkov.mrpersister.itf.mapping.IObjectMappingFactory;

/**
 *
 * This class is the starting point of all Mr. Persister use. Create an instance of PersistenceManager, then ask for
 * its factories, then create an IGenericDao instance and start reading and writing objects. Many things are cached
 * inside the PersistenceManager, so you should reuse the same instance once you have created it. Assign it to a
 * constant, or make it a singleton, like this:
 *
 * <br/><br/>
 * <code>
 * public static final PERSISTENCE_MANAGER = new PersistenceManager();
 *
 * <br/><br/>
 * IGenericDao dao = PERSISTENCE_MANAGER.getGenericDaoFactory().createDao(connection);
 * </code>
 *
 *
 * <br/><br/>
 * The PersistenceManager instance
 * should be reused throughout the application lifetime. Each application should create it's own PersistenceManager
 * instance.
 *
 * <br/><br/>
 * It is safe to share PersistenceManager instances if: <br/><br/>
 * 1) The components sharing them are reading the same type of objects from the same database.<br/>
 * 2) The components sharing them are reading different types of objects from the same or different databases.<br/>
 *
 * <br/><br/>
 * When sharing PersistenceManager instance be aware of what persistence configurations are used by the components
 * sharing the PersistenceManager instance.
 *
 *
 * @author Jakob Jenkov - Copyright 2005 Jenkov Development
 */
public class PersistenceManager {
//    private static final Map configurations = new HashMap();

    private IObjectMappingFactory            objectMappingFactory = new ObjectMappingFactory();
    private IPersistenceConfigurationFactory configurationFactory = new PersistenceConfigurationFactory();
    private IGenericDaoFactory               genericDaoFactory    = new GenericDaoFactory(this);

    /**
     * Returns the persistence configuration factory currently in use.
     * The persistence factory replaces the <code>MrPersister.createConfiguration()</code> methods.
     * @return  The persistence factory currently in use.
     */
    public synchronized IPersistenceConfigurationFactory getConfigurationFactory(){
        return configurationFactory;
    }

    /**
     * Sets the persistence configuration factory to be used with Mr. Persister in the future.
     * The persistence factory replaces the <code>MrPersister.createConfiguration()</code> methods.
     * You should never have to change the persistence factory. Only do so if you know what you
     * are doing.
     * @param factory The persistence factory to use.
     */
    public synchronized void setConfigurationFactory(IPersistenceConfigurationFactory factory){
        configurationFactory = factory;
    }


    /**
     * Returns the object method factory set for the Mr Persister API. This is by default set
     * the implementation that comes with Mr. Persister.
     * @return The object method factory set for the Mr. Persister API.
     */
    public IObjectMappingFactory getObjectMappingFactory() {
        return objectMappingFactory;
    }

    /**
      * Sets the object method factory set for the Mr Persister API. This is by default set
      * the implementation that comes with Mr. Persister.
      * @param factory The object method factory to be used with the Mr. Persister API.
      */
    public void setObjectMappingFactory(IObjectMappingFactory factory){
        objectMappingFactory = factory;
    }

    /**
     * Returns the generic dao factory currently used by Mr Persister.
     * @return The generic dao factory currently used by Mr Persister.
     */
    public IGenericDaoFactory getGenericDaoFactory(){
        return genericDaoFactory;
    }

    /**
     * Sets the generic dao factory to be used with Mr Persister. Most likely
     * you will not need to change it.
     * @param factory The generic dao factory to be used with Mr. Persister.
     */
    public synchronized void setGenericDaoFactory(IGenericDaoFactory factory){
        genericDaoFactory = factory;
    }


}
