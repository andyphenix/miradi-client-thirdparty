/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



package com.jenkov.mrpersister.itf;

/**
 * Creates a new <code>IPersistenceConfiguration</code> targeted for a specific database.
 * For some databases it is necessary to make a few adjustments to how their driver is
 * used. If you know in advance what database you are using, then you should
 * 
 *
 * @author Jakob Jenkov - Copyright 2005 Jenkov Development
 */
public class Database {

    public static final Database DEFAULT = new Database("Default - JDBC Compliant Database");
    public static final Database HSQLDB  = new Database("HSQLDB");



    protected String name = null;

    private Database(String name){
        this.name = name;
    }

    public String getName(){
        return this.name;
    }

    public boolean equals(Object o){
        return o == this;
    }





}
