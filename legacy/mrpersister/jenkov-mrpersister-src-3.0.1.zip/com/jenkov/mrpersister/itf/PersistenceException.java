/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



package com.jenkov.mrpersister.itf;

/**
 * This exception is the super type of all exceptions thrown in Mr. Persister. At present
 * it is also the only exception thrown anywhere in the Mr. Persister API, but we
 * may later throw subclasses so you can catch and handle the various exceptions more
 * precisely. The interface won't be changed though, and still only throw this super
 * type, PersistenceException.
 *
 * @author Jakob Jenkov, Jenkov Development
 */
public class PersistenceException extends Exception{

    public PersistenceException(){
    }

    public PersistenceException(String msg){
        super(msg);
    }

    public PersistenceException(String msg, Throwable throwable){
        super(msg, throwable);
    }

    public PersistenceException(Throwable throwable){
        super(throwable);
    }
}
