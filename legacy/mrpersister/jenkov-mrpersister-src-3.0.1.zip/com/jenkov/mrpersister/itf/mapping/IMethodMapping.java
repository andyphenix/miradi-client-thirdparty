/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



/**
 * User: Administrator
 */
package com.jenkov.mrpersister.itf.mapping;

import java.lang.reflect.Method;

/**
 * This interface represents the functions that both IGetterMapping and
 * ISetterMapping instances have in common (it is the super-interface
 * of both).
 *
 * <br/><br/>
 * A method method maps a method in a class (getter or setter) to a column
 * name in a table in the database.
 *
 * <br/><br/>
 * Field mappings are stored in the object mappings and used by the object reader
 * and object writer to determine what columns from the database to read and write.
 * They are also used by the SQL generator to generate the SQL to read and write
 * the objects.
 *
 * @author Jakob Jenkov, Jenkov Development
 */

public interface IMethodMapping {

    /**
     * Returns the database table column name this method method is method to.
     * @return The database table column name this method method is method to.
     */
    public String getColumnName();

    /**
     * Sets the database column name this method method is method to.
     * @param fieldName The column name to map to.
     */
    public void   setColumnName(String fieldName);


    /**
     * Returns the method instance this method method is method from.
     * @return The <code>Method</code> instance this method method is method from.
     */
    public Method  getObjectMethod();

    /**
     * The method instance this method method maps from.
     * @param member The <code>Method</code> instance this method method maps from.
     */
    public void    setObjectMethod(Method member);

    /**
     * Returns true if the database column referenced by this method method
     * is the primary key of the table it comes from.
     * @return True if the database column referenced by this method method
     * is the primary key of the table it comes from.
     *         False if not.
     * @deprecated This method doesn't properly support compound keys. The method
     *             sends a signal about if this method mapping is a primary key mapping
     *             by itself. With the new compound key facilities a primary key
     *             may consist of more than one column. Use the
     *             <code>public IKey IObjectMapping.getPrimaryKey()</code> method
     *             to access the primary key of an object mapping's table.
     */
    public boolean isPrimaryKey();

    /**
     * Sets whether or not the column referenced by this method method is the
     * primary key.
     * @param isPrimaryKey Set to true if the column referenced by this method method
     *        is the primary key of the table it comes from.
     * @deprecated This method doesn't properly support compound keys. The method
     *             sends a signal about if this method mapping is a primary key mapping
     *             by itself. With the new compound key facilities a primary key
     *             may consist of more than one column. Use the
     *             <code>public IKey IObjectMapping.getPrimaryKey()</code> method
     *             to access the primary key of an object mapping's table.
     */
    public void    setPrimaryKey(boolean isPrimaryKey);

    /**
     * Returns true if the database column referenced by this method method
     * is a foreign key. False if not. NOTE: This feature is reserved for
     * future implementations, and is not used in this release. Therefore
     * it will always return false.
     *
     * @return true if the database column referenced by this method method
     * is a foreign key. False if not. See above description
     */
    /*
    public boolean isForeignKey();
    */

    /**
     * Sets whether or not the database column referenced by this method method
     * is a foreign key or not. NOTE: This features is reserved for future
     * implementations, and is not used in this release. Set to false by default.
     * @param isForeignKey A boolean telling whether or not the database column referenced by this method method
     *                     is a foreign key or not
     */
    /*
    public void    setForeignKey(boolean isForeignKey);
    */

    
    /**
     * Returns true if the database column referenced by this method method exists in a table in the database.
     * False if not. Objects can be mapped to SQL queries with arbitrary column names not existing in the database.
     * For instance a setter method of an object can be mapped to the column name totalCount in the SQL query
     * <code>"select count(*) totalCount from employees</code>
     * @return  True if the database column referenced by this method method exists in a table in the database.
     * False if not.
     */
    public boolean isTableMapped();

    /**
     * Sets whether or not the database column referenced by this method method
     * exists in a table in the database. Set to true if it does. False if not.
     * Objects can be mapped to SQL queries with arbitrary column names not existing in the database.
     * For instance a setter method of an object can be mapped to the column name totalCount in the SQL query
     * <code>"select count(*) totalCount from employees</code>
     * @param isTableMapped
     */
    public void    setTableMapped(boolean isTableMapped);
}
