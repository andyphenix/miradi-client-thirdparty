/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



package com.jenkov.mrpersister.itf;

import com.jenkov.mrpersister.impl.GenericDao;

import java.sql.Connection;

/**
 * @author Jakob Jenkov - Copyright 2005 Jenkov Development
 */
public interface IGenericDaoFactory {

    /**
     * Creates an <code>IGenericDao</code> instance that will use the given connection
     * to do it's work.
     * @param connection The connection the generic dao is to use.
     * @return An <code>IGenericDao</code> instance.
     */
    public IGenericDao createDao(Connection connection);


    /**
     * Creates an <code>IGenericDao</code> instance that will use the given
     * connection and <code>IPersistenceConfiguration</code> instance to do it's work.
     * For more information on persistence configurations see the
     * <code>IPersistenceConfiguration</code> interface JavaDoc.
     * @param connection    The connection the generic dao is to use.
     * @param configuration The persistence configuration the dao is to use.
     * @return An <code>IGenericDao</code> instance.
     */
    public IGenericDao createDao(Connection connection, IPersistenceConfiguration configuration);


    /**
     * Creates an </code>IGenericDao</code> instance that uses the given connection
     * and the persistence configuration stored by the given key in the
     * persistence configuration factory. If no configuration is stored by that
     * key a new configuration will be created and stored for later use.
     * @param connection The connection the generic dao is to use.
     * @param configKey  The key of the persistence configuration to use / create and use.
     * @return An </code>IGenericDao</code> instance.
     */
    public IGenericDao createDao(Connection connection, Object configKey);


    
}
