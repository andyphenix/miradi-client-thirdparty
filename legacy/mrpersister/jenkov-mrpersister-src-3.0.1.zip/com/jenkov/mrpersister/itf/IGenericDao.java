/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



package com.jenkov.mrpersister.itf;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Collection;
import java.util.List;

/**
 * This interface represents a generic dao which is the preferred way of accesing Mr Persister.
 * Objects implementing this interface are capable of reading and writing objects to a database.
 * <code>IGenericDao</code> instances should be obtained from the generic dao factory available
 * from the <code>com.jenkov.mrpersister.MrPersister</code> class.
 *
 * <br/><br/>
 * Example:<br/><br/>
 *
 * IGenericDao dao = MrPersister.getGenericDaoFactory().createDao(connection);<br/>
 *
 * </code>
 *
 *
 * @author Jakob Jenkov
 *         Copyright 2004 Jenkov Development
 */
public interface IGenericDao {

    /**
     * Returns the configuration used by this <code>IGenericDao</code> instance. You can use this
     * configuration to access cached object mappings, set a custom object mapper, exchange automatic
     * object mapper etc. Just remember: The configuration instance is shared by many IGenericDao instances.
     * Make sure you do not make changes to the configuration that invalidates what other dao instances
     * is doing. Preferrably you make the changes once in the beginning of your application.
     *
     * @return The persistence configuration used by this <code>IGenericDao</code> instance.
     */
    public IPersistenceConfiguration getConfiguration();


    /**
     * Returns the connection used by this GenericDao instance.
     * @return The connection used by this GenericDao instance.
     */
    public Connection getConnection();

    /**
     * Closes the connection used by this GenericDao instance.
     * @throws com.jenkov.mrpersister.itf.PersistenceException If closing the connection fails.
     */
    public void closeConnection() throws PersistenceException;


    /**
     * Calls setAutoCommit on the underlying connection.
     * @param autoCommit True if you want auto-commit on. False if not. Use false for transactions that involves
     *        several reads / writes to the database.
     * @throws PersistenceException If an SQLException is thrown by the underlying connection.
     */
    public void setAutoCommit(boolean autoCommit) throws PersistenceException;

    /**
     * Call commit() on the underlying connection. Use this method to commit a transaction.
     */
    public void commit() throws PersistenceException;

    /**
     * Calls rollback() on the underlying connection. Use this method to roll back (undo) a transaction.
     */
    public void rollback() throws PersistenceException;



    /**
     * Reads a single object from the database using the object mapping stored by the given
     * object mapping key, and the given primary key to identify the record in the database
     * that coresponds to the object to be read. If no record/object was found by the given
     * primary key, null is returned.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be read,
     * meaning if you want to read an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param primaryKey  The primary key value identifying the record to be read into an object.
     * @return            The object coresponding to the given primary key, read according to
     *                    the given object mapping. If no record/object was found by the given
     *                    primary key, null is returned.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public Object readByPrimaryKey(Object objectMappingKey, Object primaryKey) throws PersistenceException;

    /**
     * Reads a single object from the database using the object mapping stored by the given
     * object mapping key, and the given SQL string. If the SQL string results in more than
     * one record in the <code>ResultSet</code> generated by it, only the first record in the
     * <code>ResultSet</code> will be read into an object and returned.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be read,
     * meaning if you want to read an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param sql         The SQL string locating the record to be read into an object.
     * @return            The object read using the given SQL string and object mapping stored by
     *                    the given object mapping key.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public Object read(Object objectMappingKey, String sql) throws PersistenceException;

    /**
      * Reads a single object from the given <code>ResultSet</code> using the object mapping
      * stored by the given object mapping key. If the <code>ResultSet</code> contains
      * more than one record, only the first record in the
      * <code>ResultSet</code> will be read into an object and returned.
      *
      * <br/><br/>
      * No database connection will be opened. The object will be read from the provided
      * <code>ResultSet</code>. You must remember to close the <code>ResultSet</code>
      * yourself when you are done with it.
      *
      * <br/><br/>
      * If no object mapping is stored by the given object mapping key, a new object mapping
      * will be attempted generated and stored by that object mapping key. An object mapping
      * can only be generated automatically if the method key is either a </code>Class</code>
      * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
      * with a <code>Class</code> instance set
      * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
      *
      * <br/><br/>
      * The <code>Class</code> instance should be the class of the object to be read,
      * meaning if you want to read an object of class <code>Employee</code> the
      * <code>Class</code> instance should be that found at <code>Employee.class</code>.
      *
      * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
      *                    in the object mapping cache, in the persistence configuration used by this
      *                    instance of the DAO class.
      * @param result      The <code>ResultSet</code> to read the object from.
      * @return            The object read from the <code>ResultSet</code> using the object mapping
      *                    stored by the given object mapping key.
      * @throws PersistenceException If anything goes wrong during the read, if no persistence
      *                    configuration is set, if the persistence configuration contains
      *                    no object reader, or if no object mapping could be found nor generated
      *                    from the given object mapping key.
      */
    public Object read(Object objectMappingKey, ResultSet result) throws PersistenceException;

    /**
         * Reads a single object from the database using the given <code>Statement</code>
         * instance, the given SQL string, and the object mapping
         * stored by the given object mapping key. If the <code>ResultSet</code> generated
         * by the <code>Statement</code> instance when executing the SQL string contains
         * more than one record, only the first record in the
         * <code>ResultSet</code> will be read into an object and returned.
         *
         * <br/><br/>
         * Use this method if you need to use a special/customized <code>Statement</code> instance.
         * If you don't need a special/customized <code>Statement</code> instance,
         * the other <code>read</code> methods will be easier to use.
         *
         * <br/><br/>
         * No database connection will be opened. The object will be read using the
         * provided <code>Statement</code> instance. You must remember to close the
         * <code>Statement</code> yourself when you are done with it.
         *
         *
         * <br/><br/>
         * If no object mapping is stored by the given object mapping key, a new object mapping
         * will be attempted generated and stored by that object mapping key. An object mapping
         * can only be generated automatically if the method key is either a </code>Class</code>
         * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
         * with a <code>Class</code> instance set
         * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
         *
         * <br/><br/>
         * The <code>Class</code> instance should be the class of the object to be read,
         * meaning if you want to read an object of class <code>Employee</code> the
         * <code>Class</code> instance should be that found at <code>Employee.class</code>.
         *
         * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
         *                    in the object mapping cache, in the persistence configuration used by this
         *                    instance of the DAO class.
         * @param statement   The <code>Statement</code> instance to use to execute the SQL string.
         * @param sql         The SQL string to be executed by the <code>Statement</code> instance.
         * @return
         * @throws PersistenceException If anything goes wrong during the read, if no persistence
         *                    configuration is set, if the persistence configuration contains
         *                    no object reader, or if no object mapping could be found nor generated
         *                    from the given object mapping key.
         */
    public Object read(Object objectMappingKey, Statement statement, String sql) throws PersistenceException;

    /**
     * Reads a single object from the database using the given <code>PreparedStatement</code>
     * instance, and the object mapping stored by the given object mapping key.
     * The <code>PreparedStatement</code> instance must have all parameters set before calling
     * this method (using the PreparedStatement.setXXX(index, value) methods).
     * If the <code>ResultSet</code> generated
     * by the <code>PreparedStatement</code> instance contains
     * more than one record, only the first record in the
     * <code>ResultSet</code> will be read into an object and returned.
     *
     * <br/><br/>
     * No database connection will be opened. The object will be read using the
     * <code>PreparedStatement</code> passed as parameter. You must remember to
     * close the <code>PreparedStatement</code> yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be read,
     * meaning if you want to read an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param statement   The <code>PreparedStatement</code> instance locating the object to read.
     * @return            The object read from the <code>ResultSet</code> generated by the
     *                    given <code>PreparedStatement</code>, according to the object mapping
     *                    located or generated by the given object mapping key.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public Object read(Object objectMappingKey, PreparedStatement statement) throws PersistenceException;

    /**
     * Reads a single object from the database using the given SQL string,
     * the parameters, and the object mapping stored by the given object mapping key.
     *
     * <br/><br/>
     * A <code>PreparedStatement</code> instance will be created using the
     * given SQL string, and the parameters collection will be inserted into it.
     * Therefore the SQL string should have the same format as those used with a
     * <code>PreparedStatement</code>. The parameters will be inserted in the
     * sequence returned by the parameter collection's iterator.
     *
     * <br/><br/>
     * If the <code>ResultSet</code> generated
     * by the <code>PreparedStatement</code> instance contains
     * more than one record, only the first record in the
     * <code>ResultSet</code> will be read into an object and returned.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be read,
     * meaning if you want to read an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @return            The object read from the <code>ResultSet</code> generated by the
     *                    given <code>PreparedStatement</code>, according to the object mapping
     *                    located or generated by the given object mapping key.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public Object read(Object objectMappingKey, String sql, Collection parameters) throws PersistenceException;

    /**
     * Reads a single object from the database using the given SQL string,
     * the parameters, and the object mapping stored by the given object mapping key.
     *
     * <br/><br/>
     * A <code>PreparedStatement</code> instance will be created using the
     * given SQL string, and the parameters collection will be inserted into it.
     * Therefore the SQL string should have the same format as those used with a
     * <code>PreparedStatement</code>. The parameters will be inserted in the
     * sequence returned by the parameter collection's iterator.
     *
     * <br/><br/>
     * If the <code>ResultSet</code> generated
     * by the <code>PreparedStatement</code> instance contains
     * more than one record, only the first record in the
     * <code>ResultSet</code> will be read into an object and returned.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be read,
     * meaning if you want to read an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @return            The object read from the <code>ResultSet</code> generated by the
     *                    given <code>PreparedStatement</code>, according to the object mapping
     *                    located or generated by the given object mapping key.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public Object read(Object objectMappingKey, String sql, Object[] parameters) throws PersistenceException;

    /**
     * Reads a list of objects from the database using the object mapping stored by the given
     * object mapping key, and the given primary keys to identify the records in the database
     * that coresponds to the objects to be read. If no records/objects were found by the given
     * primary keys, an empty list is returned. An empty list is also returned if the collection
     * of primary keys passed to this method is empty.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param primaryKeys The primary key values identifying the records to be read into objects.
     * @return            The list of objects coresponding to the given primary keys, read according to
     *                    the given object mapping. If no records/objects were found by the given
     *                    primary keys, an empty list is returned. An empty list is also returned
     *                    if the collection of primary keys passed to this method is empty.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public List readListByPrimaryKeys(Object objectMappingKey, Collection primaryKeys) throws PersistenceException;

    /**
     * Reads a list of objects from the database using the object mapping stored or generated
     * by the given object mapping key, and the given SQL string. The objects will appear
     * in the list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the SQL string.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param sql         The String string locating the records to be read into objects.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public List readList(Object objectMappingKey, String sql) throws PersistenceException;

    /**
     * Reads a list of objects from the given <code>ResultSet</code> using the object mapping
     * stored or generated by the given object mapping key. The objects will appear in the
     * list in the same order their coresponding records appear in the
     * <code>ResultSet</code>.
     *
     * <br/><br/>
     * No database connection will be opened. The object will be read from the provided
     * <code>ResultSet</code>. You must remember to close the <code>ResultSet</code>
     * yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param result      The <code>ResultSet</code> to read the list of objects from.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public List readList(Object objectMappingKey, ResultSet result) throws PersistenceException;

    /**
     * Reads a list of objects from the database using the given <code>Statement</code>
     * instance, the given SQL string and the object mapping
     * stored or generated by the given object mapping key. The objects will appear in the
     * list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the <code>Statement</code>'s execution of the
     * SQL string.
     *
     * <br/><br/>
     * Use this method if you need to use a special/customized <code>Statement</code> instance.
     * If you don't need a special/customized <code>Statement</code> instance,
     * the other <code>read</code> methods will be easier to use.
     *
     * No database connections will be opened. The objects will be read from the provided
     * <code>Statement</code>. You must remember
     * to close the <code>Statement</code> after your are dont with it.
     *
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     * The <code>Class</code> instance should be the class of the object to be stored,
     * meaning if you want to store an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param statement   The <code>Statement</code> instance to be used to execute the SQL string.
     * @param sql         The SQL string to be executed by the <code>Statement</code> instance.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public List readList(Object objectMappingKey, Statement statement, String sql) throws PersistenceException;

    /**
     * Reads a list of objects using the object mapping stored or generated by the given
     * object mapping key and <code>PreparedStatement</code> instance.
     * The <code>PreparedStatement</code> instance must have all parameters set before calling
     * this method (using the PreparedStatement.setXXX(index, value) methods).
     * The objects will appear in the
     * list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the <code>PreparedStatement</code> instance.
     *
     * <br/><br/>
     * No database connection will be opened. The object will be read using the
     * <code>PreparedStatement</code> passed as parameter. You must remember to
     * close the <code>PreparedStatement</code> yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param statement   The <code>PreparedStatement</code> instance locating the list of objects to read.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public List readList(Object objectMappingKey, PreparedStatement statement) throws PersistenceException;

    /**
     * Reads a list of objects using the object mapping stored or generated by the given
     * object mapping key, and a <code>PreparedStatement</code> instance created from the
     * sql parameter, and the parameter collection. A <code>PreparedStatement</code> instance
     * will be generated using the connection obtained by calling getConnection(),
     * and calling it's prepareStatement(sql), where sql is the sql parameter passed in
     * here as parameter. Hence the sql parameter must match the format used with
     * prepared statements (? - mark for parameters)
     *
     * <br/><br/>
     * The objects will appear in the
     * list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the <code>PreparedStatement</code> instance.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param  objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param  sql        The SQL string to use to prepare a <code>PreparedStatement</code>.
     * @param  parameters The parameters to insert into the <code>PreparedStatement</code>.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public List readList(Object objectMappingKey, String sql, Collection parameters) throws PersistenceException;

    /**
     * Reads a list of objects using the object mapping stored or generated by the given
     * object mapping key, and a <code>PreparedStatement</code> instance created from the
     * sql parameter, and the parameter array. A <code>PreparedStatement</code> instance
     * will be generated using the connection obtained by calling getConnection(),
     * and calling it's prepareStatement(sql), where sql is the sql parameter passed in
     * here as parameter. Hence the sql parameter must match the format used with
     * prepared statements (? - mark for parameters)
     *
     * <br/><br/>
     * The objects will appear in the
     * list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the <code>PreparedStatement</code> instance.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param  objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param  sql        The SQL string to use to prepare a <code>PreparedStatement</code>.
     * @param  parameters The parameters to insert into the <code>PreparedStatement</code>.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public List readList(Object objectMappingKey, String sql, Object[] parameters) throws PersistenceException;

    /**
     * Reads a list of objects from the database using the object mapping stored or generated
     * by the given object mapping key, and the given SQL string. The objects will appear
     * in the list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the SQL string.
     *
     * <br/><br/>
     * The filter passed as parameter can include or exclude the records as they are
     * iterated. If a filter excludes a record it will not be included in the
     * list of objects read. A filter can also end the reading by signalling
     * that it will not accept anymore records. No more records will then be iterated,
     * and the objects read so far will be returned. If null is passed in the
     * filter parameter no filtering will occur, and all records located by the
     * SQL string will be included in the returned list.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param sql         The SQL string locating the records to read into objects.
     * @param filter      A filter that can include or exclude individual records.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public List readList(Object objectMappingKey, String sql, IReadFilter filter) throws PersistenceException;

    /**
     * Reads a list of objects from the given <code>ResultSet</code> using the object mapping
     * stored or generated by the given object mapping key. The objects will appear in the
     * list in the same order their coresponding records appear in the
     * <code>ResultSet</code>.
     *
     * <br/><br/>
     * The filter passed as parameter can include or exclude the records as they are
     * iterated. If a filter excludes a record it will not be included in the
     * list of objects read. A filter can also end the reading by signalling
     * that it will not accept anymore records. No more records will then be iterated,
     * and the objects read so far will be returned. If null is passed in the
     * filter parameter no filtering will occur, and all records in the
     * <code>ResultSet</code> will be included in the returned list.
     *
     * <br/><br/>
     * No database connection will be opened. The object will be read from the provided
     * <code>ResultSet</code>. You must remember to close the <code>ResultSet</code>
     * yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param result      The <code>ResultSet</code> to read the list of objects from.
     * @param filter      A filter that can include or exclude individual records.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public List readList(Object objectMappingKey, ResultSet result, IReadFilter filter) throws PersistenceException;

    /**
     * Reads a list of objects from the database using the given <code>Statement</code>
     * instance, the given SQL string and the object mapping
     * stored or generated by the given object mapping key. The objects will appear in the
     * list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the <code>Statement</code>'s execution of the
     * SQL string.
     *
     * <br/><br/>
     * The filter passed as parameter can include or exclude the records as they are
     * iterated. If a filter excludes a record it will not be included in the
     * list of objects read. A filter can also end the reading by signalling
     * that it will not accept anymore records. No more records will then be iterated,
     * and the objects read so far will be returned. If null is passed in the
     * filter parameter no filtering will occur, and all records in the
     * <code>ResultSet</code> will be included in the returned list.
     *
     * <br/><br/>
     * Use this method if you need to use a special/customized <code>Statement</code> instance.
     * If you don't need a special/customized <code>Statement</code> instance,
     * the other <code>read</code> methods will be easier to use.
     *
     * <br/><br/>
     * No database connection will be opened. The object will be read from the provided
     * <code>Statement</code>. You must remember to close the <code>Statement</code>
     * yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param statement   The <code>Statement</code> instance to be used to execute the SQL string.
     * @param sql         The SQL string to be executed by the <code>Statement</code> instance.
     * @param filter      A filter that can include or exclude individual records.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public List readList(Object objectMappingKey, Statement statement, String sql, IReadFilter filter) throws PersistenceException;

    /**
     * Reads a list of objects using the object mapping stored or generated by the given
     * object mapping key and <code>PreparedStatement</code> instance.
     * The <code>PreparedStatement</code> instance must have all parameters set before calling
     * this method (using the PreparedStatement.setXXX(index, value) methods).
     * The objects will appear in the
     * list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the <code>PreparedStatement</code> instance.
     *
     * <br/><br/>
     * The filter passed as parameter can include or exclude the records as they are
     * iterated. If a filter excludes a record it will not be included in the
     * list of objects read. A filter can also end the reading by signalling
     * that it will not accept anymore records. No more records will then be iterated,
     * and the objects read so far will be returned. If null is passed in the
     * filter parameter no filtering will occur, and all records in the
     * <code>ResultSet</code> will be included in the returned list.
     *
     * <br/><br/>
     * No database connection will be opened. The object will be read from the provided
     * <code>PreparedStatement</code>. You must remember to close the <code>PreparedStatement</code>
     * yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be ,
     * meaning if you want to store an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param statement   The <code>PreparedStatement</code> instance locating the list of objects to read.
     * @param filter      A filter that can include or exclude individual records.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public List readList(Object objectMappingKey, PreparedStatement statement, IReadFilter filter) throws PersistenceException;

    /**
     * Reads a list of objects using the object mapping stored or generated by the given
     * object mapping key, and a <code>PreparedStatement</code> instance created from the
     * sql parameter, and the parameter array. A <code>PreparedStatement</code> instance
     * will be generated using the connection obtained by calling getConnection(),
     * and calling it's prepareStatement(sql), where sql is the sql parameter passed in
     * here as parameter. Hence the sql parameter must match the format used with
     * prepared statements (? - mark for parameters)
     *
     * <br/><br/>
     * The objects will appear in the
     * list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the <code>PreparedStatement</code> instance.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * The filter passed as parameter can include or exclude the records as they are
     * iterated. If a filter excludes a record it will not be included in the
     * list of objects read. A filter can also end the reading by signalling
     * that it will not accept anymore records. No more records will then be iterated,
     * and the objects read so far will be returned. If null is passed in the
     * filter parameter no filtering will occur, and all records in the
     * <code>ResultSet</code> will be included in the returned list.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param  sql        The SQL string to use to prepare a <code>PreparedStatement</code>.
     * @param  parameters The parameters to insert into the <code>PreparedStatement</code>.
     * @param filter      A filter that can include or exclude individual records.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public List readList(Object objectMappingKey, String sql, Collection parameters, IReadFilter filter) throws PersistenceException;

    /**
     * Reads a list of objects using the object mapping stored or generated by the given
     * object mapping key, and a <code>PreparedStatement</code> instance created from the
     * sql parameter, and the parameter array. A <code>PreparedStatement</code> instance
     * will be generated using the connection obtained by calling getConnection(),
     * and calling it's prepareStatement(sql), where sql is the sql parameter passed in
     * here as parameter. Hence the sql parameter must match the format used with
     * prepared statements (? - mark for parameters)
     *
     * <br/><br/>
     * The objects will appear in the
     * list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the <code>PreparedStatement</code> instance.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * The filter passed as parameter can include or exclude the records as they are
     * iterated. If a filter excludes a record it will not be included in the
     * list of objects read. A filter can also end the reading by signalling
     * that it will not accept anymore records. No more records will then be iterated,
     * and the objects read so far will be returned. If null is passed in the
     * filter parameter no filtering will occur, and all records in the
     * <code>ResultSet</code> will be included in the returned list.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param  sql        The SQL string to use to prepare a <code>PreparedStatement</code>.
     * @param  parameters The parameters to insert into the <code>PreparedStatement</code>.
     * @param filter      A filter that can include or exclude individual records.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public List readList(Object objectMappingKey, String sql, Object[] parameters, IReadFilter filter) throws PersistenceException;

    /**
       * Same as <code>insert(Object objectMappingKey, Object object)</code>, but
       * uses object.getClass() as the object mapping key.
       * @param object      The object containing the values to be inserted into the new record.
       * @return            The number of records affected by this insert action, as returned by
       *                    <code>PreparedStatement.executeUpdate()</code>.
       * @throws PersistenceException If anything goes wrong during the insert, if no persistence
       *                    configuration is set, if the persistence configuration contains
       *                    no object writer, or if no object mapping could be found nor generated
       *                    from the given object mapping key.
       */
    public int insert(Object object) throws PersistenceException;

    /**
        * Inserts a record in the database with the values from the given object according to the
        * object mapping stored or generated by the given object mapping key.
        *
        * <br/><br/>
        * A connection to the database will be obtained from the getConnection() method of this
        * instance.
        *
        * <br/><br/>
        * If no object mapping is stored by the given object mapping key, a new object mapping
        * will be attempted generated and stored by that object mapping key. An object mapping
        * can only be generated automatically if the method key is either a </code>Class</code>
        * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
        * with a <code>Class</code> instance set
        * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
        *
        * <br/><br/>
        * The <code>Class</code> instance should be the class of the object to be inserted,
        * meaning if you want to insert an object of class <code>Employee</code> the
        * <code>Class</code> instance should be that found at <code>Employee.class</code>.
        *
        * <br/><br/>
        * The SQL needed to insert the record will be generated automatically based on the object
        * mapping, and executed using a <code>PreparedStatement</code>.
        * The SQL string contains "?" characters for the values will be cached for later
        * use to avoid the SQL generation overhead.
        *
        * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
        *                    in the object mapping cache, in the persistence configuration used by this
        *                    instance of the DAO class.
        * @param object      The object containing the values to be inserted into the new record.
        * @return            The number of records affected by this insert action, as returned by
        *                    <code>PreparedStatement.executeUpdate()</code>.
        * @throws PersistenceException If anything goes wrong during the insert, if no persistence
        *                    configuration is set, if the persistence configuration contains
        *                    no object writer, or if no object mapping could be found nor generated
        *                    from the given object mapping key.
        */
    public int insert(Object objectMappingKey, Object object) throws PersistenceException;

    /**
     * Same as <code>insertBatch(Object objectMappingKey, Collection objects)</code> but uses
     * the class returned by the getClass() of the first element in the collection
     * as the object mapping key.
     * The first element is extracted using a standard Iterator.
     * @param objects     The object containing the values to be inserted into the new record.
     * @return            The number of records affected by this insert action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the insert, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public int[] insertBatch(Collection objects) throws PersistenceException;

    /**
     * Inserts several records into the database with the values from the given objects according to the
     * object mapping stored or generated by the given object mapping key.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be inserted,
     * meaning if you want to insert objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to insert the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param objects      The object containing the values to be inserted into the new record.
     * @return            The number of records affected by this insert action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the insert, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public int[] insertBatch(Object objectMappingKey, Collection objects) throws PersistenceException;

    /**
     * Same as <code>update(Object objectMappingKey, Object object)</code>
     * but uses the object.getClass() as the object mapping key.
     * @param object      The object containing the values to be update in the coresponding record.
     * @return            The number of records affected by this update action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public int update(Object object) throws PersistenceException;

    /**
     * Updates the record in the database coresponding to the given object, with the values
     * contained in this object, according to the object mapping stored or generated by
     * the given object mapping key.
     *
     * <br/><br/>
     * Do not
     * use this method if the primary key value is also changed during the update, or this method
     * will have no effect. If you do use it for an update where the primary key has changed,
     * the primary key value in the "where" clause of the SQL will contain the new primary key value.
     * Since no records, or perhaps another existing record, matches the new, changed, primary key value,
     * the update will have no effect. If you need to update a record including it's primary key, use
     * the other update method.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be updated,
     * meaning if you want to update an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to update the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param object      The object containing the values to be update in the coresponding record.
     * @return            The number of records affected by this update action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public int update(Object objectMappingKey, Object object) throws PersistenceException;

    /**
     * Same as <code>updateByPrimaryKey(Object objectMappingKey, Object object, Object oldPrimaryKeyValue)</code>
     * but uses the object.getClass() as the object mapping key.
     * @param object      The object containing the values to be update in the coresponding record.
     * @param oldPrimaryKeyValue The primary key value of the record to update, meaning the value of the
     *                   primary key before it was changed in the object to update.
     * @return            The number of records affected by this update action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public int updateByPrimaryKey(Object object, Object oldPrimaryKeyValue) throws PersistenceException;

    /**
     * Updates the record in the database coresponding to the given object, with the values
     * contained in this object, according to the object mapping stored or generated by
     * the given object mapping key.
     *
     * <br/><br/>
     * Use this method when updating records
     * in which you also change the primary key value. This method inserts the old
     * primary key value into the "where" clause of the PreparedStatement, so the
     * correct record is updated.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be updated,
     * meaning if you want to update an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to update the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param object      The object containing the values to be update in the coresponding record.
     * @param oldPrimaryKeyValue The primary key value of the record to update, meaning the value of the
     *                   primary key before it was changed in the object to update.
     * @return            The number of records affected by this update action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public int updateByPrimaryKey(Object objectMappingKey, Object object, Object oldPrimaryKeyValue) throws PersistenceException;

    /**
     * Same as <code>updateBatch(Object objectMappingKey, Collection objects)</code>
     * the class returned by the getClass() of the first element in the collection
     * as the object mapping key.
     * @param objects     The collection of objects containing the values for the records to be updated.
     * @return            An array containing the number of records affected by each update action, as returned by
     *                    <code>PreparedStatement.executeBatch()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public int[] updateBatch(Collection objects) throws PersistenceException;

    /**
     * Updates the records in the database coresponding to the given collection of objects, with the values
     * contained in these objects, according to the object mapping stored or generated by
     * the given object mapping key. This method uses JDBC batch updates to do the job, meaning all
     * SQL statements are batched and sent to the database in one go.
     *
     * <br/><br/>
     * Do not
     * use this method if the primary key values are also changed during the update, or this method
     * will have no effect. If you do use it for updates where the primary key has changed,
     * the primary key value in the "where" clause of the SQL will contain the new primary key value.
     * Since no records, or perhaps another existing record, match the new, changed, primary key values,
     * the update will have no effect. If you need to batch update records including their primary keys, use
     * the other updateBatch method.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be updated,
     * meaning if you want to update objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to update the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param objects     The collection of objects containing the values for the records to be updated.
     * @return            An array containing the number of records affected by each update action, as returned by
     *                    <code>PreparedStatement.executeBatch()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public int[] updateBatch(Object objectMappingKey, Collection objects) throws PersistenceException;

    /**
     * Same as <code>updateBatchByPrimaryKeys(Object objectMappingKey, Collection objects, Collection oldPrimaryKeys)</code>
     * the class returned by the getClass() of the first element in the collection
     * as the object mapping key.
     * @param objects     The collection of objects containing the values for the records to be updated.
     * @param oldPrimaryKeys The collection of old primary keys each matching an object in the objects collection.
     *                    The keys must be returned by the collection iterator in the same sequence
     *                    as the objects they match are returned by the object.iterator().
     * @return            An array containing the number of records affected by each update action, as returned by
     *                    <code>PreparedStatement.executeBatch()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */

    public int[] updateBatchByPrimaryKeys(Collection objects, Collection oldPrimaryKeys) throws PersistenceException;

    /**
         * Updates the records in the database coresponding to the given collection of objects, with the values
         * contained in these objects, according to the object mapping stored or generated by
         * the given object mapping key. This method uses JDBC batch updates to do the job, meaning all
         * SQL statements are batched and sent to the database in one go.
         *
         * <br/><br/>
         * Use this method if the primary key values are also changed during the update. The old primary
         * key values are used to identify the records to be updated. The values of the primary keys in
         * the objects are the values the the primary keys of the records will have after the update.
         *
         * <br/><br/>
         * A connection to the database will be obtained from the getConnection() method of this
         * instance.
         *
         * <br/><br/>
         * If no object mapping is stored by the given object mapping key, a new object mapping
         * will be attempted generated and stored by that object mapping key. An object mapping
         * can only be generated automatically if the method key is either a </code>Class</code>
         * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
         * with a <code>Class</code> instance set
         * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
         *
         * <br/><br/>
         * The <code>Class</code> instance should be the class of the objects to be updated,
         * meaning if you want to update objects of class <code>Employee</code> the
         * <code>Class</code> instance should be that found at <code>Employee.class</code>.
         *
         * <br/><br/>
         * The SQL needed to update the record will be generated automatically based on the object
         * mapping, and executed using a <code>PreparedStatement</code>.
         * The SQL string contains "?" characters for the values will be cached for later
         * use to avoid the SQL generation overhead.
         *
         * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
         *                    in the object mapping cache, in the persistence configuration used by this
         *                    instance of the DAO class.
         * @param objects     The collection of objects containing the values for the records to be updated.
         * @param oldPrimaryKeys The collection of old primary keys each matching an object in the objects collection.
         *                    The keys must be returned by the collection iterator in the same sequence
         *                    as the objects they match are returned by the object.iterator().
         * @return            An array containing the number of records affected by each update action, as returned by
         *                    <code>PreparedStatement.executeBatch()</code>.
         * @throws PersistenceException If anything goes wrong during the update, if no persistence
         *                    configuration is set, if the persistence configuration contains
         *                    no object writer, or if no object mapping could be found nor generated
         *                    from the given object mapping key.
         */
    public int[] updateBatchByPrimaryKeys(Object objectMappingKey, Collection objects, Collection oldPrimaryKeys) throws PersistenceException;

    /**
     * Same as <code>delete(Object objectMappingKey, Object object)</code> but uses
     * the object.getClass() as the object mapping key.
     * @param object      The object containing the primary key of the record to be deleted.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */

    public int delete(Object object) throws PersistenceException;

    /**
     * Deletes the record from the database coresponding to the given object, according to
     * the object mapping stored or generated by the given object mapping key.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be deleted,
     * meaning if you want to delete an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to delete the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains one or more "?" characters for the primary key value and will thus be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param object      The object containing the primary key of the record to be deleted.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public int delete(Object objectMappingKey, Object object) throws PersistenceException;

    /**
     * Same as <code>deleteBatch(Object objectMappingKey, Collection objects)</code>
     * but uses the class returned by the getClass() method of the first object
     * in the collection, as returned by the collection iterator, as the
     * object mapping key.
     * @param objects     The collection containing the objects to be deleted.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public int[] deleteBatch(Collection objects) throws PersistenceException;

    /**
     * Deletes the records from the database coresponding to the given objects, according to
     * the object mapping stored or generated by the given object mapping key. This method
     * uses JDBC batch updates to do the job, meaning the delete statements are batched up
     * and sent to the database in one go.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be deleted,
     * meaning if you want to delete objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to delete the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains one or more "?" characters for the primary key value and will thus be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param objects     The collection containing the objects to be deleted.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public int[] deleteBatch(Object objectMappingKey, Collection objects) throws PersistenceException;

    /**
     * Deletes the record from the database matching the given primary key, according to the
     * object mapping stored or generated by the given object mapping key.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be deleted,
     * meaning if you want to delete an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to delete the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains one or more "?" characters for the primary key value and will thus be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param primaryKey  The primary key matching the record to be deleted.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public int deleteByPrimaryKey(Object objectMappingKey, Object primaryKey) throws PersistenceException;


    /**
     * Deletes the records from the database coresponding to the given primary keys, according to
     * the object mapping stored or generated by the given object mapping key. This method
     * uses JDBC batch updates to do the job, meaning the delete statements are batched up
     * and sent to the database in one go.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * instance.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be deleted,
     * meaning if you want to delete objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to delete the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains one or more "?" characters for the primary key value and will thus be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param primaryKeys The collection containing the primary keys of the records to be deleted.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    public int[] deleteBatchByPrimaryKeys(Object objectMappingKey, Collection primaryKeys) throws PersistenceException;

    /**
     * Executes the given SQL update. Creates a <code>Statement</code> using the
     * <code>Connection</code> stored inside this GenericDao instance, then executes
     * the SQL update using that <code>Statement</code> instance.
     *
     * @param sql The SQL udpate to execute.
     * @return The number of records affected by the update, as returned by <code>Statement.executeUpdate(sql)</code>.
     * @throws PersistenceException If a Statement cannot be created, or
     *         an error occurs when attempting to execute the update.
     */
    public int executeUpdate(String sql) throws PersistenceException;

    /**
     * Executes the given SQL update. Creates a <code>PreparedStatement</code> using the
     * <code>Connection</code> stored inside this GenericDao instance, then executes
     * the SQL update using that <code>PreparedStatement</code> instance. The parameters
     * are inserted into the <code>PreparedStatement</code> instance in the sequence
     * they occur in the <code>Iterator</code> returned by the parameter collection.
     * In most cases it is easiest to use a list as the collection.
     *
     * @param sql The SQL udpate to execute.
     * @param parameters The parameters to be inserted into the <code>PreparedStatement</code>
     * @return The number of records affected by the update, as returned by
     *          <code>PreparedStatement.executeUpdate(sql)</code>.
     * @throws PersistenceException If a <code>PreparedStatement</code> cannot be created, or
     *         an error occurs when attempting to execute the update.
     */
    public int executeUpdate(String sql, Collection parameters) throws PersistenceException;

    /**
     * Executes the given SQL update. Creates a <code>PreparedStatement</code> using the
     * <code>Connection</code> stored inside this GenericDao instance, then executes
     * the SQL update using that <code>PreparedStatement</code> instance. The parameters
     * are inserted into the <code>PreparedStatement</code> instance in the sequence
     * they occur in the parameter array.
     *
     * @param sql The SQL udpate to execute.
     * @param parameters The parameters to be inserted into the <code>PreparedStatement</code>
     * @return The number of records affected by the update, as returned by
     *          <code>PreparedStatement.executeUpdate(sql)</code>.
     * @throws PersistenceException If a <code>PreparedStatement</code> cannot be created, or
     *         an error occurs when attempting to execute the update.
     */
    public int executeUpdate(String sql, Object[] parameters) throws PersistenceException;



    /**
     * NOTE: Experimental. May be implemented differently in the future.
     * Executes the given command. The connection is automatically closed afterwards.
     * @param command
     * @return
     */
    //public Object executeCommand(IGenericDaoCommand command) throws PersistenceException;

    /**
     * NOTE: Experimental. May be implemented differently in the future.
     * Executes the given transaction. The transaction is automatically committed, and the connection
     * closed afterwards.
     * @param transaction
     * @return
     */
    //public Object executeTransaction(IGenericDaoTransaction transaction) throws PersistenceException;
}
