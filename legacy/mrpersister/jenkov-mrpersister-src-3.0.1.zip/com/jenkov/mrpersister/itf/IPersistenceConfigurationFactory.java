/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



package com.jenkov.mrpersister.itf;

/**
 * @author Jakob Jenkov - Copyright 2005 Jenkov Development
 */
public interface IPersistenceConfigurationFactory {

    /**
     * Creates a new persistence configuration targeted at the default database
     * (any JDBC compliant database).
     * @return a new persistence configuration targeted at the default database.
     */
    public IPersistenceConfiguration createConfiguration();


    /**
     * Creates a new persistence configuration. Used internally by Mr. Persister.
     * @param database The database is the database the configuration should be targeted at.
     * @return A new persistence configuration.
     */
    public IPersistenceConfiguration createConfiguration(Database database);

    /**
     * Returns the <code>IPersistenceConfiguration</code> instance stored by
     * the given key. If none is stored a new will be created and stored by
     * the key for later use.
     * @param  configurationKey The key of the persistence configuration to get,
     *         or to store it by if a new instance is created.
     * @return The persistence configuration stored by the given key.
     */
    public IPersistenceConfiguration getOrCreateConfiguration(Object configurationKey);

    /**
     * Returns the <code>IPersistenceConfiguration</code> instance stored by
     * the given key. If none is stored a new will be created and stored by
     * the key for later use.
     * @param  configurationKey The key of the persistence configuration to get,
     *         or to store it by if a new instance is created.
     * @param  database         The database to target this configuration for.
     * @return The persistence configuration stored by the given key.
     */
    public IPersistenceConfiguration getOrCreateConfiguration(Object configurationKey, Database database);

    /**
     * Returns the <code>IPersistenceConfiguration</code> stored by the given key.
     * @param configurationKey The key of the configuration instance to get.
     * @return the <code>IPersistenceConfiguration</code> stored by the given key.
     */
    public IPersistenceConfiguration getConfiguration(Object configurationKey);


    /**
     * Stores the <code>IPersistenceConfiguration</code> by given key.
     * @param configurationKey The key to store the configuration instance by.
     * @param configuration The configuration to store.
     */
    public void storeConfiguration(Object configurationKey, IPersistenceConfiguration configuration);


    /**
     * Removes the <code>IPersistenceConfiguration</code> stored by the given key.
     * @param configurationKey The key of the persistence configuration to remove.
     */
    public void removeConfiguration(Object configurationKey);

}
