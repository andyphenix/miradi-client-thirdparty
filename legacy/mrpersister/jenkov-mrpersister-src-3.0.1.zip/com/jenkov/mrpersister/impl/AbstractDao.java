/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



package com.jenkov.mrpersister.impl;

import com.jenkov.mrpersister.MrPersister;
import com.jenkov.mrpersister.itf.*;
import com.jenkov.mrpersister.itf.mapping.*;
import com.jenkov.mrpersister.util.JdbcUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 * The <code>AbstractDao</code> class is the users main interface to the Mr. Persister API.
 * The <code>AbstractDao</code> class glues most of the Mr. Persister components together
 * behind the back of the user.
 *
 * <br/><br/>
 * To use the <code>AbstractDao</code> class you must create a class that extends it. This
 * subclass then has a lot of methods available that makes creating that DAO class a lot
 * easier.
 *
 * <br/><br/>
 * The <code>AbstractDao</code> uses a <code>IPersistenceConfiguration</code> instance
 * internally to group together the component instances to be used with each other.
 * By default the persistence configuration will be set to the instance returned by
 * <code>com.jenkov.mrpersister.MrPersister.getConfigurationOrFail(this.getClass())</code>.
 * That means that each AbstractDao subclass uses it's own persistence configuration.
 *
 * <br/><br/>
 * You may never have
 * to change the persistence configuration, though it may become a point of
 * congestion if you have many threads accessing the same persistence configuration
 * instance. This is because the various caches are synchronized to make sure
 * that items stored in them by one thread are visible to other threads. The more
 * DAO classes use the same persistence configuration, the more often threads will
 * be waiting for each other at the caches.
 *
 * <br/><br/>
 * To use a different persistence configuration
 * instance with a subclass of AbstractDao simply set it in the constructor of
 * the subclass by calling the setConfiguration() method inherited from AbstractDao.
 * Use the
 * <code>com.jenkov.mrpersister.MrPersister.getConfigurationOrFail(Object key)</code> to
 * get a fresh persistence configuration instance. If none is found by the given
 * key one is instantiated.
 *
 * @author Jakob Jenkov, Jenkov Development
 */
public abstract class AbstractDao {

    protected IPersistenceConfiguration configuration =
            MrPersister.getConfigurationFactory().getOrCreateConfiguration(this.getClass());

    /**
     * Override this method to return a database connection to the database you want to connect to.
     * @return A connection to the database of your choice.
     */
    protected abstract Connection getConnection() throws PersistenceException;

    /**
     * Closes the given <code>ResultSet</code>
     * @param result The <code>ResultSet</code> to close.
     * @throws PersistenceException If the <code>ResultSet</code> could not be closed.
     */
    protected void close(ResultSet result) throws PersistenceException{
            JdbcUtil.close(result);
    }

    /**
     * Closes the given <code>Statement</code>
     * @param statement The <code>Statement</code> to close.
     * @throws PersistenceException If the <code>Statement</code> could not be closed.
     */
    protected void close(Statement statement) throws PersistenceException{
            JdbcUtil.close(statement);
    }

    /**
     * Closes the given <code>PreparedStatement</code>
     * @param statement The <code>PreparedStatement</code> to close.
     * @throws PersistenceException If the <code>PreparedStatement</code> could not be closed.
     */
    protected void close(PreparedStatement statement) throws PersistenceException{
            JdbcUtil.close(statement);
    }


    /**
     * Closes the given <code>Connection</code>
     * @param connection The <code>Connection</code> to close.
     * @throws PersistenceException If the <code>Connection</code> could not be closed.
     */
    protected void close(Connection connection) throws PersistenceException{
        JdbcUtil.close(connection);
    }


    /**
     * A utility method that returns the object mapping factory instance returned
     * by <code>MrPersister.getObjectMappingFactory()</code>. This method just
     * makes it easier to access the object mapping factory.
     *
     */
    protected IObjectMappingFactory getObjectMappingFactory(){
        return MrPersister.getObjectMappingFactory();
    }

    /**
     * Returns the persistence configuration used by this DAO class.
     * @return The <code>IPersistenceConfiguration</code> used by this DAO class.
     * @throws PersistenceException If no persistence configuration is set.
     */
    protected IPersistenceConfiguration getConfiguration() throws PersistenceException{
        if(this.configuration == null){
            throw new PersistenceException("No persistence configuration set in DAO (is null)");
        }
        return this.configuration;
    }

    /**
     * Sets the persistence configuration to be used by this DAO class. Should not be null.
     * @param configuration The <code>IPersistenceConfiguration</code> to be used by this
     *                      DAO class.
     */
    protected void setConfiguration(IPersistenceConfiguration configuration){
        this.configuration = configuration;
    }

    /**
     * Override this method to provide a table name for an object mapping key (a class to be mapped)
     * If this method returns null the AbstractDao will ask the ObjectMapper to try to guess the
     * matching table for a class. By returning the correct name in this method you can specify exactly
     * what table to map a class to. Example:
     *<br/><br/>
     * <code>
     *  protected String getTableName(Object objectMappingKey) {<br/>
     *  &nbsp;&nbsp;&nbsp;&nbsp;if(Employee.class.equals(objectMappingKey)){ return �workers�; } <br/>
     *  &nbsp;&nbsp;&nbsp;&nbsp;return null;<br/>
     *  }<br/>
     *
     * @param objectMappingKey The object mapping key to check for a specific table name for.
     * @return  The specific table name to map the given class to, or null if the ObjectMapper is
     *          try to guess the table name.
     */
    protected String getTableName(Object objectMappingKey) {
        return null;
    }

    /**
     * Override this method to provide a manually created object mapping for an object mapping key
     * (a class to be mapped).
     * If this method returns null the AbstractDao will ask the ObjectMapper to try to guess table
     * and column names for the given class.
     *
     * <br/><br/>
     * The object mapping returned by this method will be cached for later use.
     * @param objectMappingKey The object mapping key of the class to be mapped.
     * @return A manually created object mapping matching the object mapping key that was passed in
     *         as parameter, or null if the ObjectMapper is to generate an object mapping.
     * @throws PersistenceException If anything goes wrong during the creation of the object mapping.
     */
    protected IObjectMapping createManualObjectMapping(Object objectMappingKey) throws PersistenceException{
        return null;
    }

    /**
     * Creates an object mapping that maps the class to a table and fields in the
     * database by guessing the table and column names.

     * @param theClass The class to create the object mapping for.
     * @return An object mapping instance matching this class.
     * @throws PersistenceException If no IObjectMapper is present in the IPersistenceConfiguration in this
     * DAO instance. Also if something goes wrong during the method.
     */
    protected IObjectMapping createObjectMapping(Class theClass) throws PersistenceException{
        Connection connection = getConnection();
        try{        return getObjectMapper().mapToTable(theClass, null, connection, null, null); }
        finally{    close(connection); }
    }


    /**
     * Creates an object mapping that maps the class to the table with the table name given in the
     * tableName parameter. This method should be used if the table name does not resemble the class
     * name.
     * @param theClass   The class to generate an object mapping for.
     * @param tableName  The name of the table to map the given class to.
     * @return An autogenerated object mapping, method the given class to the given table.
     * @throws PersistenceException If anything goes wrong during the method, or if no
     *                   object mapper set in the persistence configuration.
     */
    protected IObjectMapping createObjectMapping(Class theClass, String tableName)
    throws PersistenceException{
        Connection connection = getConnection();
        try{        return getObjectMapper().mapToTable(theClass, null, connection, null, tableName); }
        finally{    close(connection); }
    }


    /**
     * Returns the object mapper set in the persistence configuration used by this DAO class.
     * @return The object mapper set in the persistence configuration used by this DAO class.
     * @throws PersistenceException If no object mapper is set in the used persistence configuration.
     */
    protected IObjectMapper getObjectMapper() throws PersistenceException {
        if(getConfiguration().getObjectMapper() == null){
            throw new PersistenceException("No object mapper set in persistence configuration in DAO (is null)");
        }

        return getConfiguration().getObjectMapper();
    }


    /**
     * Returns the object mapping cache from the persistence configuration used by this DAO class.
     * If no object mapping cache is set null is returned.
     * @return The object mapping cache from the persistence configuration used by this DAO class. Null
     *         if no object mapping cache is set in the persistence configuration.
     * @throws PersistenceException If no persistence configuration is set for this DAO class.
     */
    protected IObjectMappingCache getObjectMappingCache() throws PersistenceException {
        return getConfiguration().getObjectMappingCache();
    }


    /**
     * Returns the object mapping stored in the object mapping cache by the given method key.
     * If no object mapping is stored in the object mapping cache by that key, first the method
     * <code>createManualObjectMapping(objectMappingKey)</code> will be called to see if the
     * concrete AbstractDao subclass
     * has a manual object mapping it wants to use for the given object mapping key.
     *
     * <br/><br/>
     * If <code>createManualObjectMapping()</code> returns null, then this method will call
     * the <code>getTableName(objectMappingKey)</code> to see if the concrete AbstractDao subclass wants
     * to map the object to a certain database table, that cannot be guessed automatically
     * from the name of the mapped class. If <code>getTableName(objectMappingKey)</code> returns null,
     *
     * a new object mapping is auto-generated if possible. An object mapping can be generated if the method key
     * used is a <code>Class</code> instance (f.x. Employees.class), or an instance of
     * <code>ObjectMappingKey</code> with a <code>Class</code> instance filled in.
     * If an object mapping is generated it will be stored in the object
     * method cache under the given method key for later use.
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be stored, meaning
     * if you want to store objects of the class Employee, the class instance should be
     * Employee.class.
     * @param objectMappingKey  The key by which the object mapping to return is stored.
     * @return            The object mapping stored by the given method key.
     * @throws PersistenceException If no object mapping is stored in the object mapping cache and
     *                    no object mapping could be generated, or if something goes wrong during the
     *                    generation of the object mapping if one can be generated.
     */
    protected IObjectMapping getObjectMapping(Object objectMappingKey) throws PersistenceException {
        if(getObjectMappingCache() != null && getObjectMappingCache().containsObjectMapping(objectMappingKey)){
            return getObjectMappingCache().getObjectMapping(objectMappingKey);
        }

        IObjectMapping mapping = createManualObjectMapping(objectMappingKey);

        if(mapping != null){
            getObjectMappingCache().storeObjectMapping(objectMappingKey, mapping);
            return mapping;
        }

        if(objectMappingKey instanceof Class){
            mapping = createObjectMapping((Class) objectMappingKey, getTableName(objectMappingKey));
            getObjectMappingCache().storeObjectMapping(objectMappingKey, mapping);
            return mapping;
        }

        if(objectMappingKey instanceof IObjectMappingKey){
            if(((IObjectMappingKey) objectMappingKey).getObjectClass() != null){
                mapping = createObjectMapping(((IObjectMappingKey) objectMappingKey).getObjectClass(), getTableName(objectMappingKey));
                getObjectMappingCache().storeObjectMapping(objectMappingKey, mapping);
                return mapping;
            }
        }

        throw new PersistenceException("No object mapping stored in the object mapping cache for the" +
                "object mapping key: " + objectMappingKey + ", and no object mapping could be generated for it either.");

    }


    /**
     * Returns the object reader used in the persistence configuration used by this DAO class.
     * @return The <code>IObjectReader</code> instance set in the persistence configuration used
     *         by this DAO class.
     * @throws PersistenceException If no <code>IObjectReader</code> instance is set in the
     *         used persistence configuration.
     */
    protected IObjectReader getObjectReader() throws PersistenceException{
        if(getConfiguration().getObjectReader() == null){
            throw new PersistenceException("No object reader set in persistence configuration in DAO (is null)");
        }
        return getConfiguration().getObjectReader();
    }


    /**
     * Returns the object writer used in the persistence configuration used by this DAO class.
     * @return The <code>IObjectWriter</code> instance set in the persistence configuration used
     *         by this DAO class.
     * @throws PersistenceException If no <code>IObjectWriter</code> instance is set in the
     *         used persistence configuration.
     */
    protected IObjectWriter getObjectWriter() throws PersistenceException{
        if(getConfiguration().getObjectWriter() == null){
            throw new PersistenceException("No object writer set in persistence configuration in DAO (is null)");
        }
        return getConfiguration().getObjectWriter();
    }

    /**
     * Returns the SQL generator used in the persistence configuration used by this DAO class.
     * @return The <code>ISqlGenerator</code> instance set in the persistence configuration used by this DAO class.
     * @throws PersistenceException If no <code>ISqlGenerator</code> instance is set in the
     *         used persistence configuration.
     */
    protected ISqlGenerator getSqlGenerator() throws PersistenceException{
        if(getConfiguration().getSqlGenerator() == null) {
            throw new PersistenceException("No SQL generator set in persistence configuration in DAO (is null)");
        }
        return getConfiguration().getSqlGenerator();
    }


    /**
     * Returns the SQL string stored in the given cache by the given object mapping key. If the
     * cache parameter is null, null is returned from this method.
     *
     * @param objectMappingKey The object mapping key by which the desired SQL string is stored.
     * @param cache      The <code>ISqlCache</code> instance in which the desired SQL string is stored.
     * @return           The SQL string if found. Null if no SQL string is stored in the cache by
     *                   this object mapping key. Null if the cache parameter is null.
     */
    protected String getSqlFromCache(Object objectMappingKey, ISqlCache cache) {
        if(cache == null) return null;
        return cache.getStatement(objectMappingKey);
    }

    /**
     * Stores the given SQL string in the given cache. If the cache parameter is null
     * nothing happens.
     *
     * @param objectMappingKey The object mapping key under which to store the SQL string.
     * @param cache      The <code>ISqlCache</code> to store the SQL string in.
     * @param sql        The SQL string to store.
     */
    protected void storeSqlInCache(Object objectMappingKey, ISqlCache cache, String sql){
        if(cache == null) return;
        cache.storeStatement(objectMappingKey, sql);
    }




    //============================
    // Single Object Read Methods
    //============================

    /**
     * Reads a single object from the database using the object mapping stored by the given
     * object mapping key, and the given primary key to identify the record in the database
     * that coresponds to the object to be read. If no record/object was found by the given
     * primary key, null is returned.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * class.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be read,
     * meaning if you want to read an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param primaryKey  The primary key value identifying the record to be read into an object.
     * @return            The object coresponding to the given primary key, read according to
     *                    the given object mapping. If no record/object was found by the given
     *                    primary key, null is returned.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected Object readByPrimaryKey(Object objectMappingKey, Object primaryKey) throws PersistenceException{
        Connection connection = getConnection();

        try{
            return readByPrimaryKey(objectMappingKey, primaryKey, connection);
        } finally {
            close(connection);
        }
   }


    /**
     * Reads a single object from the database using the object mapping stored by the given
     * object mapping key, and the given primary key to identify the record in the database
     * that coresponds to the object to be read. If no record/object was found by the given
     * primary key, null is returned.
     *
     * <br/><br/>
     * The connection passed as parameter will be used for the read. This method is useful
     * when you don't want the connection closed automatically at the end of the method call.
     * For instance when this method call is a part of a transaction.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be read,
     * meaning if you want to read an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param primaryKey  The primary key value identifying the record to be read into an object.
     * @param connection  The database connection to use for the operation.
     * @return            The object coresponding to the given primary key, read according to
     *                    the given object mapping. If no record/object was found by the given
     *                    primary key, null is returned.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected Object readByPrimaryKey(Object objectMappingKey, Object primaryKey, Connection connection) throws PersistenceException{
        IObjectMapping mapping = getObjectMapping(objectMappingKey);
        String sql = getSqlFromCache(objectMappingKey, getConfiguration().getReadByPrimaryKeySqlCache());

        if(sql == null){
            sql       = getSqlGenerator().generateReadByPrimaryKeyStatement(mapping);
            storeSqlInCache(objectMappingKey, getConfiguration().getReadByPrimaryKeySqlCache(), sql);
        }
        return getObjectReader().readByPrimaryKey(mapping, primaryKey, sql, connection);
   }


   /**
    * Reads a single object from the database using the object mapping stored by the given
    * object mapping key, and the given SQL string. If the SQL string results in more than
    * one record in the <code>ResultSet</code> generated by it, only the first record in the
    * <code>ResultSet</code> will be read into an object and returned.
    *
    * <br/><br/>
    * A connection to the database will be obtained from the getConnection() method of this
    * class.
    *
    * <br/><br/>
    * If no object mapping is stored by the given object mapping key, a new object mapping
    * will be attempted generated and stored by that object mapping key. An object mapping
    * can only be generated automatically if the method key is either a </code>Class</code>
    * instance, or a <code>com.jenkov.mrpersister.impl.ObjectMappingKey</code> instance
    * with a <code>Class</code> instance set
    * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
    *
    * <br/><br/>
    * The <code>Class</code> instance should be the class of the object to be read,
    * meaning if you want to read an object of class <code>Employee</code> the
    * <code>Class</code> instance should be that found at <code>Employee.class</code>.
    *
    * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
    *                    in the object mapping cache, in the persistence configuration used by this
    *                    instance of the DAO class.
    * @param sql         The SQL string locating the record to be read into an object.
    * @return            The object read using the given SQL string and object mapping stored by
    *                    the given object mapping key.
    * @throws PersistenceException If anything goes wrong during the read, if no persistence
    *                    configuration is set, if the persistence configuration contains
    *                    no object reader, or if no object mapping could be found nor generated
    *                    from the given object mapping key.
    */
    protected Object read(Object objectMappingKey, String sql) throws PersistenceException{
        Connection connection = getConnection();
        try{        return read(objectMappingKey, sql, connection); }
        finally{    close(connection); }
    }

   /**
    * Reads a single object from the database using the object mapping stored by the given
    * object mapping key, and the given SQL string. If the SQL string results in more than
    * one record in the <code>ResultSet</code> generated by it, only the first record in the
    * <code>ResultSet</code> will be read into an object and returned.
    *
    * <br/><br/>
    * The connection passed as parameter will be used for the read. This method is useful
    * when you don't want the connection closed automatically at the end of the method call.
    * For instance when this method call is a part of a transaction.
    *
    * <br/><br/>
    * If no object mapping is stored by the given object mapping key, a new object mapping
    * will be attempted generated and stored by that object mapping key. An object mapping
    * can only be generated automatically if the method key is either a </code>Class</code>
    * instance, or a <code>com.jenkov.mrpersister.impl.ObjectMappingKey</code> instance
    * with a <code>Class</code> instance set
    * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
    *
    * <br/><br/>
    * The <code>Class</code> instance should be the class of the object to be read,
    * meaning if you want to read an object of class <code>Employee</code> the
    * <code>Class</code> instance should be that found at <code>Employee.class</code>.
    *
    * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
    *                    in the object mapping cache, in the persistence configuration used by this
    *                    instance of the DAO class.
    * @param sql         The SQL string locating the record to be read into an object.
    * @param connection  The database connection to use for the operation.
    * @return            The object read using the given SQL string and object mapping stored by
    *                    the given object mapping key.
    * @throws PersistenceException If anything goes wrong during the read, if no persistence
    *                    configuration is set, if the persistence configuration contains
    *                    no object reader, or if no object mapping could be found nor generated
    *                    from the given object mapping key.
    */
    protected Object read(Object objectMappingKey, String sql, Connection connection) throws PersistenceException{
        return getObjectReader().read(getObjectMapping(objectMappingKey), sql, connection);
    }

    /**
     * Reads a single object from the given <code>ResultSet</code> using the object mapping
     * stored by the given object mapping key. If the <code>ResultSet</code> contains
     * more than one record, only the first record in the
     * <code>ResultSet</code> will be read into an object and returned.
     *
     * <br/><br/>
     * No database connection will be opened. The object will be read from the provided
     * <code>ResultSet</code>. You must remember to close the <code>ResultSet</code>
     * yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be read,
     * meaning if you want to read an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param result      The <code>ResultSet</code> to read the object from.
     * @return            The object read from the <code>ResultSet</code> using the object mapping
     *                    stored by the given object mapping key.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected Object read(Object objectMappingKey, ResultSet result) throws PersistenceException{
        return getObjectReader().read(getObjectMapping( objectMappingKey), result);
    }



    /**
     * Reads a single object from the database using the given <code>Statement</code>
     * instance, the given SQL string, and the object mapping
     * stored by the given object mapping key. If the <code>ResultSet</code> generated
     * by the <code>Statement</code> instance when executing the SQL string contains
     * more than one record, only the first record in the
     * <code>ResultSet</code> will be read into an object and returned.
     *
     * <br/><br/>
     * Use this method if you need to use a special/customized <code>Statement</code> instance.
     * If you don't need a special/customized <code>Statement</code> instance,
     * the other <code>read</code> methods will be easier to use.
     *
     * <br/><br/>
     * No database connection will be opened. The object will be read using the
     * provided <code>Statement</code> instance. You must remember to close the
     * <code>Statement</code> yourself when you are done with it.
     *
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be read,
     * meaning if you want to read an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param statement   The <code>Statement</code> instance to use to execute the SQL string.
     * @param sql         The SQL string to be executed by the <code>Statement</code> instance.
     * @return
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected Object read(Object objectMappingKey, Statement statement, String sql ) throws PersistenceException{
        return getObjectReader().read(getObjectMapping( objectMappingKey), statement, sql);
    }




    /**
     * Reads a single object from the database using the given <code>PreparedStatement</code>
     * instance, and the object mapping stored by the given object mapping key.
     * The <code>PreparedStatement</code> instance must have all parameters set before calling
     * this method (using the PreparedStatement.setXXX(index, value) methods).
     * If the <code>ResultSet</code> generated
     * by the <code>PreparedStatement</code> instance contains
     * more than one record, only the first record in the
     * <code>ResultSet</code> will be read into an object and returned.
     *
     * <br/><br/>
     * No database connection will be opened. The object will be read using the
     * <code>PreparedStatement</code> passed as parameter. You must remember to
     * close the <code>PreparedStatement</code> yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be read,
     * meaning if you want to read an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param statement   The <code>PreparedStatement</code> instance locating the object to read.
     * @return            The object read from the <code>ResultSet</code> generated by the
     *                    given <code>PreparedStatement</code>, according to the object mapping
     *                    located or generated by the given object mapping key.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected Object read(Object objectMappingKey, PreparedStatement statement) throws PersistenceException{
        return getObjectReader().read(getObjectMapping(objectMappingKey), statement);
    }


    //==============================
    // Object List Read Methods
    //==============================

    /**
     * Reads a list of objects from the database using the object mapping stored by the given
     * object mapping key, and the given primary keys to identify the records in the database
     * that coresponds to the objects to be read. If no records/objects were found by the given
     * primary keys, an empty list is returned. An empty list is also returned if the collection
     * of primary keys passed to this method is empty.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * class.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param primaryKeys The primary key values identifying the records to be read into objects.
     * @return            The list of objects coresponding to the given primary keys, read according to
     *                    the given object mapping. If no records/objects were found by the given
     *                    primary keys, an empty list is returned. An empty list is also returned
     *                    if the collection of primary keys passed to this method is empty.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected List readListByPrimaryKeys(Object objectMappingKey, Collection primaryKeys) throws PersistenceException{
        Connection connection = getConnection();
        try{
            return readListByPrimaryKeys(objectMappingKey, primaryKeys, connection);
        } finally {
            close(connection);
        }
   }


    /**
     * Reads a list of objects from the database using the object mapping stored by the given
     * object mapping key, and the given primary keys to identify the records in the database
     * that coresponds to the objects to be read. If no records/objects were found by the given
     * primary keys, an empty list is returned. An empty list is also returned if the collection
     * of primary keys passed to this method is empty.
     *
     * <br/><br/>
     * The connection passed as parameter will be used for the read. This method is useful
     * when you don't want the connection closed automatically at the end of the method call.
     * For instance when this method call is a part of a transaction.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param primaryKeys The primary key values identifying the records to be read into objects.
     * @param connection  The database connection to use for the operation.
     * @return            The list of objects coresponding to the given primary keys, read according to
     *                    the given object mapping. If no records/objects were found by the given
     *                    primary keys, an empty list is returned. An empty list is also returned
     *                    if the collection of primary keys passed to this method is empty.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected List readListByPrimaryKeys(Object objectMappingKey, Collection primaryKeys, Connection connection)
    throws PersistenceException{
        if(primaryKeys.size() == 0) return new ArrayList();
        IObjectMapping mapping = getObjectMapping(objectMappingKey);
        String  sql = getSqlGenerator().generateReadListByPrimaryKeysStatement(mapping, primaryKeys.size());
        return getObjectReader().readListByPrimaryKeys(mapping, primaryKeys, sql, connection);
   }


    /**
     * Reads a list of objects from the database using the object mapping stored or generated
     * by the given object mapping key, and the given SQL string. The objects will appear
     * in the list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the SQL string.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * class.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param sql         The String string locating the records to be read into objects.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected List readList(Object objectMappingKey, String sql) throws PersistenceException{
        Connection connection = getConnection();
        try{        return readList(objectMappingKey, sql, connection);}
        finally{    close(connection); }
    }


    /**
     * Reads a list of objects from the database using the object mapping stored or generated
     * by the given object mapping key, and the given SQL string. The objects will appear
     * in the list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the SQL string.
     *
     * <br/><br/>
     * The connection passed as parameter will be used for the read. This method is useful
     * when you don't want the connection closed automatically at the end of the method call.
     * For instance when this method call is a part of a transaction.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param sql         The String string locating the records to be read into objects.
     * @param connection  The database connection to use for the operation.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected List readList(Object objectMappingKey, String sql, Connection connection)
    throws PersistenceException{
        return getObjectReader().readList(getObjectMapping(objectMappingKey), sql, connection);
    }

    /**
     * Reads a list of objects from the given <code>ResultSet</code> using the object mapping
     * stored or generated by the given object mapping key. The objects will appear in the
     * list in the same order their coresponding records appear in the
     * <code>ResultSet</code>.
     *
     * <br/><br/>
     * No database connection will be opened. The object will be read from the provided
     * <code>ResultSet</code>. You must remember to close the <code>ResultSet</code>
     * yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param result      The <code>ResultSet</code> to read the list of objects from.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected List readList(Object objectMappingKey, ResultSet result) throws PersistenceException{
         return getObjectReader().readList(getObjectMapping(objectMappingKey), result);
    }


    /**
     * Reads a list of objects from the database using the given <code>Statement</code>
     * instance, the given SQL string and the object mapping
     * stored or generated by the given object mapping key. The objects will appear in the
     * list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the <code>Statement</code>'s execution of the
     * SQL string.
     *
     * <br/><br/>
     * Use this method if you need to use a special/customized <code>Statement</code> instance.
     * If you don't need a special/customized <code>Statement</code> instance,
     * the other <code>read</code> methods will be easier to use.
     *
     * No database connections will be opened. The objects will be read from the provided
     * <code>Statement</code>. You must remember
     * to close the <code>Statement</code> after your are dont with it.
     *
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     * The <code>Class</code> instance should be the class of the object to be stored,
     * meaning if you want to store an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param statement   The <code>Statement</code> instance to be used to execute the SQL string.
     * @param sql         The SQL string to be executed by the <code>Statement</code> instance.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected List readList(Object objectMappingKey, Statement statement, String sql) throws PersistenceException{
        return getObjectReader().readList(getObjectMapping(objectMappingKey), statement, sql);
    }

    /**
     * Reads a list of objects using the object mapping stored or generated by the given
     * object mapping key and <code>PreparedStatement</code> instance.
     * The <code>PreparedStatement</code> instance must have all parameters set before calling
     * this method (using the PreparedStatement.setXXX(index, value) methods).
     * The objects will appear in the
     * list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the <code>PreparedStatement</code> instance.
     *
     * <br/><br/>
     * No database connection will be opened. The object will be read using the
     * <code>PreparedStatement</code> passed as parameter. You must remember to
     * close the <code>PreparedStatement</code> yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param statement   The <code>PreparedStatement</code> instance locating the list of objects to read.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected List readList(Object objectMappingKey, PreparedStatement statement) throws PersistenceException{
        return getObjectReader().readList(getObjectMapping(objectMappingKey), statement);
    }


    //==================================
    // Filtered Object List Read Methods
    //==================================


    /**
     * Reads a list of objects from the database using the object mapping stored or generated
     * by the given object mapping key, and the given SQL string. The objects will appear
     * in the list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the SQL string.
     *
     * <br/><br/>
     * The filter passed as parameter can include or exclude the records as they are
     * iterated. If a filter excludes a record it will not be included in the
     * list of objects read. A filter can also end the reading by signalling
     * that it will not accept anymore records. No more records will then be iterated,
     * and the objects read so far will be returned. If null is passed in the
     * filter parameter no filtering will occur, and all records located by the
     * SQL string will be included in the returned list.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * class.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param sql         The SQL string locating the records to read into objects.
     * @param filter      A filter that can include or exclude individual records.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected List readList(Object objectMappingKey, String sql, IReadFilter filter) throws PersistenceException{
        Connection connection = getConnection();
        try{        return readList(objectMappingKey, sql, connection, filter); }
        finally{    close(connection); }
    }

    /**
     * Reads a list of objects from the database using the object mapping stored or generated
     * by the given object mapping key, and the given SQL string. The objects will appear
     * in the list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the SQL string.
     *
     * <br/><br/>
     * The filter passed as parameter can include or exclude the records as they are
     * iterated. If a filter excludes a record it will not be included in the
     * list of objects read. A filter can also end the reading by signalling
     * that it will not accept anymore records. No more records will then be iterated,
     * and the objects read so far will be returned. If null is passed in the
     * filter parameter no filtering will occur, and all records located by the
     * SQL string will be included in the returned list.
     *
     * <br/><br/>
     * The connection passed as parameter will be used for the read. This method is useful
     * when you don't want the connection closed automatically at the end of the method call.
     * For instance when this method call is a part of a transaction.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param sql         The SQL string locating the records to read into objects.
     * @param connection  The database connection to use for the operation.
     * @param filter      A filter that can include or exclude individual records.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected List readList(Object objectMappingKey, String sql, Connection connection, IReadFilter filter) throws PersistenceException{
        return getObjectReader().readList(getObjectMapping(objectMappingKey), sql, connection, filter);
    }


   /**
    * Reads a list of objects from the given <code>ResultSet</code> using the object mapping
    * stored or generated by the given object mapping key. The objects will appear in the
    * list in the same order their coresponding records appear in the
    * <code>ResultSet</code>.
    *
    * <br/><br/>
    * The filter passed as parameter can include or exclude the records as they are
    * iterated. If a filter excludes a record it will not be included in the
    * list of objects read. A filter can also end the reading by signalling
    * that it will not accept anymore records. No more records will then be iterated,
    * and the objects read so far will be returned. If null is passed in the
    * filter parameter no filtering will occur, and all records in the
    * <code>ResultSet</code> will be included in the returned list.
    *
    * <br/><br/>
    * No database connection will be opened. The object will be read from the provided
    * <code>ResultSet</code>. You must remember to close the <code>ResultSet</code>
    * yourself when you are done with it.
    *
    * <br/><br/>
    * If no object mapping is stored by the given object mapping key, a new object mapping
    * will be attempted generated and stored by that object mapping key. An object mapping
    * can only be generated automatically if the method key is either a </code>Class</code>
    * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
    * with a <code>Class</code> instance set
    * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
    *
    * <br/><br/>
    * The <code>Class</code> instance should be the class of the objects to be read,
    * meaning if you want to read objects of class <code>Employee</code> the
    * <code>Class</code> instance should be that found at <code>Employee.class</code>.
    *
    * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
    *                    in the object mapping cache, in the persistence configuration used by this
    *                    instance of the DAO class.
    * @param result      The <code>ResultSet</code> to read the list of objects from.
    * @param filter      A filter that can include or exclude individual records.
    * @return            A <code>List</code> of objects read from the database.
    * @throws PersistenceException If anything goes wrong during the read, if no persistence
    *                    configuration is set, if the persistence configuration contains
    *                    no object reader, or if no object mapping could be found nor generated
    *                    from the given object mapping key.
    */
    protected List readList(Object objectMappingKey, ResultSet result, IReadFilter filter) throws PersistenceException{
        return getObjectReader().readList(getObjectMapping(objectMappingKey), result, filter);
    }

    /**
     * Reads a list of objects from the database using the given <code>Statement</code>
     * instance, the given SQL string and the object mapping
     * stored or generated by the given object mapping key. The objects will appear in the
     * list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the <code>Statement</code>'s execution of the
     * SQL string.
     *
     * <br/><br/>
     * The filter passed as parameter can include or exclude the records as they are
     * iterated. If a filter excludes a record it will not be included in the
     * list of objects read. A filter can also end the reading by signalling
     * that it will not accept anymore records. No more records will then be iterated,
     * and the objects read so far will be returned. If null is passed in the
     * filter parameter no filtering will occur, and all records in the
     * <code>ResultSet</code> will be included in the returned list.
     *
     * <br/><br/>
     * Use this method if you need to use a special/customized <code>Statement</code> instance.
     * If you don't need a special/customized <code>Statement</code> instance,
     * the other <code>read</code> methods will be easier to use.
     *
     * <br/><br/>
     * No database connection will be opened. The object will be read from the provided
     * <code>Statement</code>. You must remember to close the <code>Statement</code>
     * yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be read,
     * meaning if you want to read objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param statement   The <code>Statement</code> instance to be used to execute the SQL string.
     * @param sql         The SQL string to be executed by the <code>Statement</code> instance.
     * @param filter      A filter that can include or exclude individual records.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected List readList(Object objectMappingKey, Statement statement, String sql, IReadFilter filter) throws PersistenceException{
        return getObjectReader().readList(getObjectMapping(objectMappingKey), statement, sql, filter);
    }

    /**
     * Reads a list of objects using the object mapping stored or generated by the given
     * object mapping key and <code>PreparedStatement</code> instance.
     * The <code>PreparedStatement</code> instance must have all parameters set before calling
     * this method (using the PreparedStatement.setXXX(index, value) methods).
     * The objects will appear in the
     * list in the same order their coresponding records appear in the
     * <code>ResultSet</code> generated by the <code>PreparedStatement</code> instance.
     *
     * <br/><br/>
     * The filter passed as parameter can include or exclude the records as they are
     * iterated. If a filter excludes a record it will not be included in the
     * list of objects read. A filter can also end the reading by signalling
     * that it will not accept anymore records. No more records will then be iterated,
     * and the objects read so far will be returned. If null is passed in the
     * filter parameter no filtering will occur, and all records in the
     * <code>ResultSet</code> will be included in the returned list.
     *
     * <br/><br/>
     * No database connection will be opened. The object will be read from the provided
     * <code>PreparedStatement</code>. You must remember to close the <code>PreparedStatement</code>
     * yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be ,
     * meaning if you want to store an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param statement   The <code>PreparedStatement</code> instance locating the list of objects to read.
     * @param filter      A filter that can include or exclude individual records.
     * @return            A <code>List</code> of objects read from the database.
     * @throws PersistenceException If anything goes wrong during the read, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object reader, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected List readList(Object objectMappingKey, PreparedStatement statement, IReadFilter filter) throws PersistenceException{
        return getObjectReader().readList(getObjectMapping(objectMappingKey), statement, filter);
    }


    //==================================
    // Insert / Update / Delete Methods
    //==================================

    /**
     * Inserts a record in the database with the values from the given object according to the
     * object mapping stored or generated by the given object mapping key.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * class.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be inserted,
     * meaning if you want to insert an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to insert the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param object      The object containing the values to be inserted into the new record.
     * @return            The number of records affected by this insert action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the insert, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int insert(Object objectMappingKey, Object object) throws PersistenceException{
        Connection connection = getConnection();

        try{
            return insert(objectMappingKey, object, connection);
        }finally {
            close(connection);
        }
    }

    /**
     * Same as <code>insert(Object objectMappingKey, Object object)</code>, but
     * uses object.getClass() as the object mapping key.
     * @param object      The object containing the values to be inserted into the new record.
     * @return            The number of records affected by this insert action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the insert, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int insert(Object object) throws PersistenceException{
        return insert(object.getClass(), object);
    }


    /**
     * Inserts a record in the database with the values from the given object according to the
     * object mapping stored or generated by the given object mapping key.
     *
     * <br/><br/>
     * The provided connection will be used to insert the object into the database. This can
     * be useful with tables that has an auto-incrementing field for the primary key, and
     * where you have to use the connection after the insert to retrieve the latest id generated
     * by that connection. HSQLDB works that way. You can also use this method to insert
     * records as part of a transaction you are controlling with the given connection.
     * Remember to close the connection yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectobjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be inserted,
     * meaning if you want to insert an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to insert the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param object      The object containing the values to be inserted into the new record.
     * @param connection  The database connection to use for the operation.
     * @return            The number of records affected by this insert action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the insert, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int insert(Object objectMappingKey, Object object, Connection connection) throws PersistenceException{
        IObjectMapping  mapping = getObjectMapping(objectMappingKey);
        String          sql     = getSqlFromCache(mapping, getConfiguration().getInsertSqlCache());

        if(sql == null){
            sql = getSqlGenerator().generateInsertStatement(mapping);
            storeSqlInCache(mapping, getConfiguration().getInsertSqlCache(), sql);
        }
        return getObjectWriter().insert(mapping, object, sql, connection);
    }

    /**
     * Same as <code>insert(Object objectMappingKey, Object object, Connection connection)</code>, but
     * uses object.getClass() as the object mapping key.
     * @param object      The object containing the values to be inserted into the new record.
     * @param connection  The database connection to use for the operation.
     * @return            The number of records affected by this insert action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the insert, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int insert(Object object, Connection connection) throws PersistenceException{
        return insert(object.getClass(), object, connection);
    }


    /**
     * Inserts several records into the database with the values from the given objects according to the
     * object mapping stored or generated by the given object mapping key.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * class.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be inserted,
     * meaning if you want to insert objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to insert the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param objects      The object containing the values to be inserted into the new record.
     * @return            The number of records affected by this insert action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the insert, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int[] insertBatch(Object objectMappingKey, Collection objects) throws PersistenceException{
        Connection connection = getConnection();

        try{
            return insertBatch(objectMappingKey, objects, connection);
        }finally {
            close(connection);
        }
    }

    /**
     * Same as <code>insertBatch(Object objectMappingKey, Collection objects)</code> but uses
     * the class returned by the getClass() of the first element in the collection
     * as the object mapping key.
     * The first element is extracted using a standard Iterator.
     * @param objects     The object containing the values to be inserted into the new record.
     * @return            The number of records affected by this insert action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the insert, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int[] insertBatch(Collection objects) throws PersistenceException{
        if(objects.size() > 0){
            Iterator iterator = objects.iterator();
            Class objectMappingKey = iterator.next().getClass();
            return insertBatch(objectMappingKey, objects);
        }
        return new int[0];
    }



    /**
     * Inserts a record in the database with the values from the given object according to the
     * object mapping stored or generated by the given object mapping key.
     *
     * <br/><br/>
     * The provided connection will be used to insert the object into the database. This can
     * be useful with tables that has an auto-incrementing field for the primary key, and
     * where you have to use the connection after the insert to retrieve the latest id generated
     * by that connection. HSQLDB works that way. You can also use this method to insert
     * records as part of a transaction you are controlling with the given connection.
     * Remember to close the connection yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be inserted,
     * meaning if you want to insert objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to insert the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param objects      The object containing the values to be inserted into the new record.
     * @param connection  The database connection to use for the operation.
     * @return            The number of records affected by this insert action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the insert, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int[] insertBatch(Object objectMappingKey, Collection objects, Connection connection) throws PersistenceException{
        IObjectMapping  mapping = getObjectMapping(objectMappingKey);
        String          sql     = getSqlFromCache(mapping, getConfiguration().getInsertSqlCache());

        if(sql == null){
            sql = getSqlGenerator().generateInsertStatement(mapping);
            storeSqlInCache(mapping, getConfiguration().getInsertSqlCache(), sql);
        }
        return getObjectWriter().insertBatch(mapping, objects, sql, connection);
    }

    /**
     * Same as <code>insertBatch(Object objectMappingKey, Collection objects, Connection connection)</code>
     * the class returned by the getClass() of the first element in the collection
     * as the object mapping key.
     * @param objects      The object containing the values to be inserted into the new record.
     * @param connection  The database connection to use for the operation.
     * @return            The number of records affected by this insert action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the insert, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int[] insertBatch(Collection objects, Connection connection) throws PersistenceException{
        if(objects.size() > 0){
            Iterator iterator = objects.iterator();
            Class objectMappingKey = iterator.next().getClass();
            return insertBatch(objectMappingKey, objects, connection);
        }
        return new int[0];
    }


    /**
     * Updates the record in the database coresponding to the given object, with the values
     * contained in this object, according to the object mapping stored or generated by
     * the given object mapping key.
     *
     * <br/><br/>
     * Do not
     * use this method if the primary key value is also changed during the update, or this method
     * will have no effect. If you do use it for an update where the primary key has changed,
     * the primary key value in the "where" clause of the SQL will contain the new primary key value.
     * Since no records, or perhaps another existing record, matches the new, changed, primary key value,
     * the update will have no effect. If you need to update a record including it's primary key, use
     * the other update method.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * class.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be updated,
     * meaning if you want to update an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to update the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param object      The object containing the values to be update in the coresponding record.
     * @return            The number of records affected by this update action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int update(Object objectMappingKey, Object object) throws PersistenceException{
        Connection connection = getConnection();
        try{
            return update(objectMappingKey, object, connection);
        } finally {
            close(connection);
        }
    }

    /**
     * Same as <code>update(Object objectMappingKey, Object object)</code>
     * but uses the object.getClass() as the object mapping key.
     * @param object      The object containing the values to be update in the coresponding record.
     * @return            The number of records affected by this update action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int update(Object object) throws PersistenceException{
        return update(object.getClass(), object);
    }


    /**
     * Updates the record in the database coresponding to the given object, with the values
     * contained in this object, according to the object mapping stored or generated by
     * the given object mapping key.
     *
     * <br/><br/>
     * Do not
     * use this method if the primary key value is also changed during the update, or this method
     * will have no effect. If you do use it for an update where the primary key has changed,
     * the primary key value in the "where" clause of the SQL will contain the new primary key value.
     * Since no records, or perhaps another existing record, matches the new, changed, primary key value,
     * the update will have no effect. If you need to update a record including it's primary key, use
     * the other update method.
     *
     * <br/><br/>
     * The provided connection will be used to update the objects in the database.
     * This can be useful when updating objects as part of a transaction, or just
     * want to reuse the connection for several tasks. Remember to close the
     * connection yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be updated,
     * meaning if you want to update an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to update the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param object      The object containing the values to be update in the coresponding record.
     * @param connection  The database connection to use for the operation.
     * @return            The number of records affected by this update action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int update(Object objectMappingKey, Object object, Connection connection) throws PersistenceException{
        IObjectMapping  mapping = getObjectMapping(objectMappingKey);
        String          sql     = getSqlFromCache(mapping, getConfiguration().getUpdateSqlCache());
        if(sql == null){
            sql = getSqlGenerator().generateUpdateStatement(mapping);
            storeSqlInCache(mapping, getConfiguration().getUpdateSqlCache(), sql);
        }
        return getObjectWriter().update(mapping, object, sql, connection);
    }

    /**
     * Same as <code>update(Object objectMappingKey, Object object, Connection connection)</code>
     * but uses the object.getClass() as the object mapping key.
     * @param object      The object containing the values to be update in the coresponding record.
     * @param connection  The database connection to use for the operation.
     * @return            The number of records affected by this update action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int update(Object object, Connection connection) throws PersistenceException{
        return update(object.getClass(), object, connection);
    }


    /**
     * Updates the record in the database coresponding to the given object, with the values
     * contained in this object, according to the object mapping stored or generated by
     * the given object mapping key.
     *
     * <br/><br/>
     * Use this method when updating records
     * in which you also change the primary key value. This method inserts the old
     * primary key value into the "where" clause of the PreparedStatement, so the
     * correct record is updated.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * class.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be updated,
     * meaning if you want to update an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to update the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param object      The object containing the values to be update in the coresponding record.
     * @param oldPrimaryKeyValue The primary key value of the record to update, meaning the value of the
     *                   primary key before it was changed in the object to update.
     * @return            The number of records affected by this update action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @deprecated        Use the updateByPrimaryKey instead(). Renamed to avoid naming conflict.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int update(Object objectMappingKey, Object object, Object oldPrimaryKeyValue) throws PersistenceException{
        Connection connection = getConnection();
        try{
            return update(objectMappingKey, object, oldPrimaryKeyValue, connection);
        } finally {
            close(connection);
        }
    }

   /**
    * Updates the record in the database coresponding to the given object, with the values
    * contained in this object, according to the object mapping stored or generated by
    * the given object mapping key.
    *
    * <br/><br/>
    * Use this method when updating records
    * in which you also change the primary key value. This method inserts the old
    * primary key value into the "where" clause of the PreparedStatement, so the
    * correct record is updated.
    *
    * <br/><br/>
    * A connection to the database will be obtained from the getConnection() method of this
    * class.
    *
    * <br/><br/>
    * If no object mapping is stored by the given object mapping key, a new object mapping
    * will be attempted generated and stored by that object mapping key. An object mapping
    * can only be generated automatically if the method key is either a </code>Class</code>
    * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
    * with a <code>Class</code> instance set
    * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
    *
    * <br/><br/>
    * The <code>Class</code> instance should be the class of the object to be updated,
    * meaning if you want to update an object of class <code>Employee</code> the
    * <code>Class</code> instance should be that found at <code>Employee.class</code>.
    *
    * <br/><br/>
    * The SQL needed to update the record will be generated automatically based on the object
    * mapping, and executed using a <code>PreparedStatement</code>.
    * The SQL string contains "?" characters for the values will be cached for later
    * use to avoid the SQL generation overhead.
    *
    * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
    *                    in the object mapping cache, in the persistence configuration used by this
    *                    instance of the DAO class.
    * @param object      The object containing the values to be update in the coresponding record.
    * @param oldPrimaryKeyValue The primary key value of the record to update, meaning the value of the
    *                   primary key before it was changed in the object to update.
    * @return            The number of records affected by this update action, as returned by
    *                    <code>PreparedStatement.executeUpdate()</code>.
    * @throws PersistenceException If anything goes wrong during the update, if no persistence
    *                    configuration is set, if the persistence configuration contains
    *                    no object writer, or if no object mapping could be found nor generated
    *                    from the given object mapping key.
    */
    protected int updateByPrimaryKey(Object objectMappingKey, Object object, Object oldPrimaryKeyValue)
    throws PersistenceException{
       Connection connection = getConnection();
       try{
           return updateByPrimaryKey(objectMappingKey, object, oldPrimaryKeyValue, connection);
       } finally {
           close(connection);
       }
    }

    /**
     * Same as <code>updateByPrimaryKey(Object objectMappingKey, Object object, Object oldPrimaryKeyValue)</code>
     * but uses the object.getClass() as the object mapping key.
     * @param object      The object containing the values to be update in the coresponding record.
     * @param oldPrimaryKeyValue The primary key value of the record to update, meaning the value of the
     *                   primary key before it was changed in the object to update.
     * @return            The number of records affected by this update action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int updateByPrimaryKey(Object object, Object oldPrimaryKeyValue) throws PersistenceException{
        return updateByPrimaryKey(object.getClass(), object, oldPrimaryKeyValue);
    }


    /**
     * Updates the record in the database coresponding to the given object, with the values
     * contained in this object, according to the object mapping stored or generated by
     * the given object mapping key.
     *
     * <br/><br/>
     * Use this method when updating records
     * in which you also change the primary key value. This method inserts the old
     * primary key value into the "where" clause of the PreparedStatement, so the
     * correct record is updated.
     *
     * <br/><br/>
     * The provided connection will be used to update the object in the database.
     * This can be useful when updating an object as part of a transaction, or just
     * want to reuse the connection for several tasks. Remember to close the
     * connection yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be updated,
     * meaning if you want to update an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to update the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param object      The object containing the values to be update in the coresponding record.
     * @param oldPrimaryKeyValue The primary key value of the record to update, meaning the value of the
     *                    primary key before it was changed in the object to update.
     * @param connection  The database connection to use for the operation.
     * @return            The number of records affected by this update action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     * @deprecated        Use the updateByPrimaryKey method instead. Renamed to avoid naming conflict.
     */
    protected int update(Object objectMappingKey, Object object, Object oldPrimaryKeyValue, Connection connection)
    throws PersistenceException{
        IObjectMapping  mapping = getObjectMapping(objectMappingKey);
        String          sql     = getSqlFromCache(mapping, getConfiguration().getUpdateSqlCache());

        if(sql == null){
            sql = getSqlGenerator().generateUpdateStatement(mapping);
            storeSqlInCache(mapping, getConfiguration().getUpdateSqlCache(), sql);
        }

        return getObjectWriter().update(mapping, object, oldPrimaryKeyValue, sql, connection);
    }

    /**
     * Updates the record in the database coresponding to the given object, with the values
     * contained in this object, according to the object mapping stored or generated by
     * the given object mapping key.
     *
     * <br/><br/>
     * Use this method when updating records
     * in which you also change the primary key value. This method inserts the old
     * primary key value into the "where" clause of the PreparedStatement, so the
     * correct record is updated.
     *
     * <br/><br/>
     * The provided connection will be used to update the object in the database.
     * This can be useful when updating an object as part of a transaction, or just
     * want to reuse the connection for several tasks. Remember to close the
     * connection yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be updated,
     * meaning if you want to update an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to update the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param object      The object containing the values to be update in the coresponding record.
     * @param oldPrimaryKeyValue The primary key value of the record to update, meaning the value of the
     *                    primary key before it was changed in the object to update.
     * @param connection  The database connection to use for the operation.
     * @return            The number of records affected by this update action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int updateByPrimaryKey(Object objectMappingKey, Object object, Object oldPrimaryKeyValue, Connection connection)
    throws PersistenceException{
        IObjectMapping  mapping = getObjectMapping(objectMappingKey);
        String          sql     = getSqlFromCache(mapping, getConfiguration().getUpdateSqlCache());

        if(sql == null){
            sql = getSqlGenerator().generateUpdateStatement(mapping);
            storeSqlInCache(mapping, getConfiguration().getUpdateSqlCache(), sql);
        }

        return getObjectWriter().update(mapping, object, oldPrimaryKeyValue, sql, connection);
    }

    /**
     * Same as <code>updateByPrimaryKey(Object objectMappingKey, Object object, Object oldPrimaryKeyValue,
     * Connection connection)</code> but uses the object.getClass() as the object mapping key.
     * @param object      The object containing the values to be update in the coresponding record.
     * @param oldPrimaryKeyValue The primary key value of the record to update, meaning the value of the
     *                    primary key before it was changed in the object to update.
     * @param connection  The database connection to use for the operation.
     * @return            The number of records affected by this update action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int updateByPrimaryKey(Object object, Object oldPrimaryKeyValue, Connection connection)
    throws PersistenceException{
        return updateByPrimaryKey(object.getClass(), object, oldPrimaryKeyValue, connection);
    }

    /**
     * Updates the records in the database coresponding to the given collection of objects, with the values
     * contained in these objects, according to the object mapping stored or generated by
     * the given object mapping key. This method uses JDBC batch updates to do the job, meaning all
     * SQL statements are batched and sent to the database in one go.
     *
     * <br/><br/>
     * Do not
     * use this method if the primary key values are also changed during the update, or this method
     * will have no effect. If you do use it for updates where the primary key has changed,
     * the primary key value in the "where" clause of the SQL will contain the new primary key value.
     * Since no records, or perhaps another existing record, match the new, changed, primary key values,
     * the update will have no effect. If you need to batch update records including their primary keys, use
     * the other updateBatch method.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * class.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be updated,
     * meaning if you want to update objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to update the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param objects     The collection of objects containing the values for the records to be updated.
     * @return            An array containing the number of records affected by each update action, as returned by
     *                    <code>PreparedStatement.executeBatch()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int[] updateBatch(Object objectMappingKey, Collection objects) throws PersistenceException{
        Connection connection = getConnection();
        try{
            return updateBatch(objectMappingKey, objects,  connection);
        } finally {
            close(connection);
        }
    }

   /**
    * Same as <code>updateBatch(Object objectMappingKey, Collection objects)</code>
    * the class returned by the getClass() of the first element in the collection
    * as the object mapping key.
    * @param objects     The collection of objects containing the values for the records to be updated.
    * @return            An array containing the number of records affected by each update action, as returned by
    *                    <code>PreparedStatement.executeBatch()</code>.
    * @throws PersistenceException If anything goes wrong during the update, if no persistence
    *                    configuration is set, if the persistence configuration contains
    *                    no object writer, or if no object mapping could be found nor generated
    *                    from the given object mapping key.
    */

    protected int[] updateBatch(Collection objects) throws PersistenceException{
        if(objects.size() > 0){
            Iterator iterator = objects.iterator();
            Class objectMappingKey = iterator.next().getClass();
            return updateBatch(objectMappingKey, objects);
        }
        return new int[0];
    }



    /**
     * Updates the records in the database coresponding to the given collection of objects, with the values
     * contained in these objects, according to the object mapping stored or generated by
     * the given object mapping key. This method uses JDBC batch updates to do the job, meaning all
     * SQL statements are batched and sent to the database in one go.
     *
     * <br/><br/>
     * Do not
     * use this method if the primary key values are also changed during the update, or this method
     * will have no effect. If you do use it for updates where the primary key has changed,
     * the primary key value in the "where" clause of the SQL will contain the new primary key value.
     * Since no records, or perhaps another existing record, match the new, changed, primary key values,
     * the update will have no effect. If you need to batch update records including their primary keys, use
     * the other updateBatch method.
     *
     * <br/><br/>
     * The provided connection will be used to update the objects in the database.
     * This can be useful when updating objects as part of a transaction, or just
     * want to reuse the connection for several tasks. Remember to close the
     * connection yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be updated,
     * meaning if you want to update objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to update the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param objects     The collection of objects containing the values for the records to be updated.
     * @param connection  The database connection to use for the operation.
     * @return            An array containing the number of records affected by each update action, as returned by
     *                    <code>PreparedStatement.executeBatch()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int[] updateBatch(Object objectMappingKey, Collection objects, Connection connection)
    throws PersistenceException{
        IObjectMapping  mapping = getObjectMapping(objectMappingKey);
        String          sql     = getSqlFromCache(mapping, getConfiguration().getUpdateSqlCache());

        if(sql == null){
            sql = getSqlGenerator().generateUpdateStatement(mapping);
            storeSqlInCache(mapping, getConfiguration().getUpdateSqlCache(), sql);
        }

        return getObjectWriter().updateBatch(mapping, objects, sql, connection);
    }


    /**
     * Same as <code>updateBatch(Object objectMappingKey, Collection objects, Connection connection)</code>
     * the class returned by the getClass() of the first element in the collection
     * as the object mapping key.
     * @param objects     The collection of objects containing the values for the records to be updated.
     * @return            An array containing the number of records affected by each update action, as returned by
     *                    <code>PreparedStatement.executeBatch()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */

     protected int[] updateBatch(Collection objects, Connection connection) throws PersistenceException{
         if(objects.size() > 0){
             Iterator iterator = objects.iterator();
             Class objectMappingKey = iterator.next().getClass();
             return updateBatch(objectMappingKey, objects, connection);
         }
         return new int[0];
     }


    /**
     * Updates the records in the database coresponding to the given collection of objects, with the values
     * contained in these objects, according to the object mapping stored or generated by
     * the given object mapping key. This method uses JDBC batch updates to do the job, meaning all
     * SQL statements are batched and sent to the database in one go.
     *
     * <br/><br/>
     * Use this method if the primary key values are also changed during the update. The old primary
     * key values are used to identify the records to be updated. The values of the primary keys in
     * the objects are the values the the primary keys of the records will have after the update.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * class.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be updated,
     * meaning if you want to update objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to update the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param objects     The collection of objects containing the values for the records to be updated.
     * @return            An array containing the number of records affected by each update action, as returned by
     *                    <code>PreparedStatement.executeBatch()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     * @deprecated        Use the updateBatchByPrimaryKeys instead. Renamed to avoid naming conflict.
     */
    protected int[] updateBatch(Object objectMappingKey, Collection objects, Collection oldPrimaryKeys) throws PersistenceException{
        Connection connection = getConnection();
        try{
            return updateBatch(objectMappingKey, objects, oldPrimaryKeys, connection);
        } finally {
            close(connection);
        }
    }


    /**
     * Updates the records in the database coresponding to the given collection of objects, with the values
     * contained in these objects, according to the object mapping stored or generated by
     * the given object mapping key. This method uses JDBC batch updates to do the job, meaning all
     * SQL statements are batched and sent to the database in one go.
     *
     * <br/><br/>
     * Use this method if the primary key values are also changed during the update. The old primary
     * key values are used to identify the records to be updated. The values of the primary keys in
     * the objects are the values the the primary keys of the records will have after the update.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * class.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be updated,
     * meaning if you want to update objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to update the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param objects     The collection of objects containing the values for the records to be updated.
     * @param oldPrimaryKeys The collection of old primary keys each matching an object in the objects collection.
     *                    The keys must be returned by the collection iterator in the same sequence
     *                    as the objects they match are returned by the object.iterator().
     * @return            An array containing the number of records affected by each update action, as returned by
     *                    <code>PreparedStatement.executeBatch()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int[] updateBatchByPrimaryKeys(Object objectMappingKey, Collection objects, Collection oldPrimaryKeys) throws PersistenceException{
        Connection connection = getConnection();
        try{
            return updateBatchByPrimaryKeys(objectMappingKey, objects, oldPrimaryKeys, connection);
        } finally {
            close(connection);
        }
    }

    /**
     * Same as <code>updateBatchByPrimaryKeys(Object objectMappingKey, Collection objects, Collection oldPrimaryKeys)</code>
     * the class returned by the getClass() of the first element in the collection
     * as the object mapping key.
     * @param objects     The collection of objects containing the values for the records to be updated.
     * @param oldPrimaryKeys The collection of old primary keys each matching an object in the objects collection.
     *                    The keys must be returned by the collection iterator in the same sequence
     *                    as the objects they match are returned by the object.iterator().
     * @return            An array containing the number of records affected by each update action, as returned by
     *                    <code>PreparedStatement.executeBatch()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */

     protected int[] updateBatchByPrimaryKeys(Collection objects, Collection oldPrimaryKeys) throws PersistenceException{
         if(objects.size() > 0){
             Iterator iterator = objects.iterator();
             Class objectMappingKey = iterator.next().getClass();
             return updateBatchByPrimaryKeys(objectMappingKey, objects, oldPrimaryKeys);
         }
         return new int[0];
     }




    /**
     * Updates the records in the database coresponding to the given collection of objects, with the values
     * contained in these objects, according to the object mapping stored or generated by
     * the given object mapping key. This method uses JDBC batch updates to do the job, meaning all
     * SQL statements are batched and sent to the database in one go.
     *
     * <br/><br/>
     * Use this method if the primary key values are also changed during the update. The old primary
     * key values are used to identify the records to be updated. The values of the primary keys in
     * the objects are the values the the primary keys of the records will have after the update.
     *
     * <br/><br/>
     * The provided connection will be used to update the objects in the database.
     * This can be useful when updating objects as part of a transaction, or just
     * want to reuse the connection for several tasks. Remember to close the
     * connection yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be updated,
     * meaning if you want to update objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to update the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param objects     The collection of objects containing the values for the records to be updated.
     * @param connection  The database connection to use for the operation.
     * @param oldPrimaryKeys The collection of old primary keys each matching an object in the objects collection.
     *                    The keys must be returned by the collection iterator in the same sequence
     *                    as the objects they match are returned by the object.iterator().
     * @return            An array containing the number of records affected by each update action, as returned by
     *                    <code>PreparedStatement.executeBatch()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     * @deprecated        Use the updateBatchByPrimaryKeys instead. Renamed to avoid naming conflict.
     */
    protected int[] updateBatch(Object objectMappingKey, Collection objects, Collection oldPrimaryKeys,
                                Connection connection)
    throws PersistenceException{
        IObjectMapping  mapping = getObjectMapping(objectMappingKey);
        String          sql     = getSqlFromCache(mapping, getConfiguration().getUpdateSqlCache());

        if(sql == null){
            sql = getSqlGenerator().generateUpdateStatement(mapping);
            storeSqlInCache(mapping, getConfiguration().getUpdateSqlCache(), sql);
        }

        return getObjectWriter().updateBatch(mapping, objects, oldPrimaryKeys, sql, connection);
    }


    /**
     * Updates the records in the database coresponding to the given collection of objects, with the values
     * contained in these objects, according to the object mapping stored or generated by
     * the given object mapping key. This method uses JDBC batch updates to do the job, meaning all
     * SQL statements are batched and sent to the database in one go.
     *
     * <br/><br/>
     * Use this method if the primary key values are also changed during the update. The old primary
     * key values are used to identify the records to be updated. The values of the primary keys in
     * the objects are the values the the primary keys of the records will have after the update.
     *
     * <br/><br/>
     * The provided connection will be used to update the objects in the database.
     * This can be useful when updating objects as part of a transaction, or just
     * want to reuse the connection for several tasks. Remember to close the
     * connection yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be updated,
     * meaning if you want to update objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to update the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains "?" characters for the values will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param objects     The collection of objects containing the values for the records to be updated.
     * @param connection  The database connection to use for the operation.
     * @param oldPrimaryKeys The collection of old primary keys each matching an object in the objects collection.
     *                    The keys must be returned by the collection iterator in the same sequence
     *                    as the objects they match are returned by the object.iterator().
     * @return            An array containing the number of records affected by each update action, as returned by
     *                    <code>PreparedStatement.executeBatch()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int[] updateBatchByPrimaryKeys(Object objectMappingKey, Collection objects, Collection oldPrimaryKeys,
                                Connection connection)
    throws PersistenceException{
        IObjectMapping  mapping = getObjectMapping(objectMappingKey);
        String          sql     = getSqlFromCache(mapping, getConfiguration().getUpdateSqlCache());

        if(sql == null){
            sql = getSqlGenerator().generateUpdateStatement(mapping);
            storeSqlInCache(mapping, getConfiguration().getUpdateSqlCache(), sql);
        }

        return getObjectWriter().updateBatch(mapping, objects, oldPrimaryKeys, sql, connection);
    }

    /**
     * Same as <code>updateBatchByPrimaryKeys(Object objectMappingKey, Collection objects, Collection oldPrimaryKeys,
     *    Connection connection)</code> but uses the class returned by the getClass() method of the first object
     * in the collection as the object mapping key.
     * @param objects     The collection of objects containing the values for the records to be updated.
     * @param connection  The database connection to use for the operation.
     * @param oldPrimaryKeys The collection of old primary keys each matching an object in the objects collection.
     *                    The keys must be returned by the collection iterator in the same sequence
     *                    as the objects they match are returned by the object.iterator().
     * @return            An array containing the number of records affected by each update action, as returned by
     *                    <code>PreparedStatement.executeBatch()</code>.
     * @throws PersistenceException If anything goes wrong during the update, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int[] updateBatchByPrimaryKeys(Collection objects, Collection oldPrimaryKeys, Connection connection)
    throws PersistenceException{
        if(objects.size() > 0){
            Iterator iterator = objects.iterator();
            Class objectMappingKey = iterator.next().getClass();
            return updateBatchByPrimaryKeys(objectMappingKey, objects, oldPrimaryKeys, connection);
        }
        return new int[0];

    }

    /**
     * Deletes the record from the database coresponding to the given object, according to
     * the object mapping stored or generated by the given object mapping key.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * class.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be deleted,
     * meaning if you want to delete an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to delete the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains a "?" character for the primary key value will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param object      The object containing the primary key of the record to be deleted.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int delete(Object objectMappingKey, Object object) throws PersistenceException{
        Connection connection = getConnection();
        try{
            return delete(objectMappingKey, object, connection);
        } finally {
            close(connection);
        }
    }

    /**
     * Same as <code>delete(Object objectMappingKey, Object object)</code> but uses
     * the object.getClass() as the object mapping key.
     * @param object      The object containing the primary key of the record to be deleted.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */

    protected int delete(Object object) throws PersistenceException{
        return delete(object.getClass(), object);
    }


    /**
     * Deletes the record from the database coresponding to the given object, according to
     * the object mapping stored or generated by the given object mapping key.
     *
     * <br/><br/>
     * The provided connection will be used to delete the object in the database.
     * This can be useful when deleting an object as part of a transaction, or just
     * want to reuse the connection for several tasks. Remember to close the
     * connection yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be deleted,
     * meaning if you want to delete an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to delete the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains a "?" character for the primary key value will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param object      The object containing the primary key of the record to be deleted.
     * @param connection  The database connection to use for the operation.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int delete(Object objectMappingKey, Object object, Connection connection) throws PersistenceException{
        IObjectMapping  mapping = getObjectMapping(objectMappingKey);
        String          sql     = getSqlFromCache(mapping, getConfiguration().getDeleteSqlCache());

        if(sql == null){
            sql = getSqlGenerator().generateDeleteStatement(mapping);
            storeSqlInCache(mapping, getConfiguration().getDeleteSqlCache(), sql);
        }
        return getObjectWriter().delete(mapping, object, sql, connection);
    }


    /**
     * Same as <code>delete(Object objectMappingKey, Object object, Connection connection)</code> but uses
     * the object.getClass() as the object mapping key.
     * @param object      The object containing the primary key of the record to be deleted.
     * @param connection  The database connection to use for the operation.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int delete(Object object, Connection connection) throws PersistenceException{
        return delete(object.getClass(), object, connection);
    }



    /**
     * Deletes the records from the database coresponding to the given objects, according to
     * the object mapping stored or generated by the given object mapping key. This method
     * uses JDBC batch updates to do the job, meaning the delete statements are batched up
     * and sent to the database in one go.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * class.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be deleted,
     * meaning if you want to delete objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to delete the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains a "?" character for the primary key value will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param objects     The collection containing the objects to be deleted.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int[] deleteBatch(Object objectMappingKey, Collection objects) throws PersistenceException{
        Connection connection = getConnection();
        try{
            return deleteBatch(objectMappingKey, objects, connection);
        } finally {
            close(connection);
        }
    }


    /**
     * Same as <code>deleteBatch(Object objectMappingKey, Collection objects)</code>
     * but uses the class returned by the getClass() method of the first object
     * in the collection, as returned by the collection iterator, as the
     * object mapping key.
     * @param objects     The collection containing the objects to be deleted.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int[] deleteBatch(Collection objects) throws PersistenceException{
        if(objects.size() > 0){
            Iterator iterator = objects.iterator();
            Class objectMappingKey = iterator.next().getClass();
            return deleteBatch(objectMappingKey, objects);
        }
        return new int[0];
    }



    /**
     * Deletes the records from the database coresponding to the given objects, according to
     * the object mapping stored or generated by the given object mapping key. This method
     * uses JDBC batch updates to do the job, meaning the delete statements are batched up
     * and sent to the database in one go.
     *
     * <br/><br/>
     * The provided connection will be used to delete the objects in the database.
     * This can be useful when deleting objects as part of a transaction, or just
     * want to reuse the connection for several tasks. Remember to close the
     * connection yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be deleted,
     * meaning if you want to delete objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to delete the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains a "?" character for the primary key value will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param objects     The collection containing the objects to be deleted.
     * @param connection  The database connection to use for the operation.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int[] deleteBatch(Object objectMappingKey, Collection objects, Connection connection) throws PersistenceException{
        IObjectMapping  mapping = getObjectMapping(objectMappingKey);
        String          sql     = getSqlFromCache(mapping, getConfiguration().getDeleteSqlCache());

        if(sql == null){
            sql = getSqlGenerator().generateDeleteStatement(mapping);
            storeSqlInCache(mapping, getConfiguration().getDeleteSqlCache(), sql);
        }

        return getObjectWriter().deleteBatch(mapping, objects, sql, connection);
    }

    /**
     * Same as <code>deleteBatch(Object objectMappingKey, Collection objects, Connection connection)</code>
     * but uses the class returned by the getClass() method of the first object
     * in the collection, as returned by the collection iterator, as the
     * object mapping key.
     *
     * @param objects     The collection containing the objects to be deleted.
     * @param connection  The database connection to use for the operation.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int[] deleteBatch(Collection objects, Connection connection) throws PersistenceException{
        if(objects.size() > 0){
            Iterator iterator = objects.iterator();
            Class objectMappingKey = iterator.next().getClass();
            return deleteBatch(objectMappingKey, objects, connection);
        }
        return new int[0];
    }


    /**
     * Deletes the record from the database matching the given primary key, according to the
     * object mapping stored or generated by the given object mapping key.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * class.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be deleted,
     * meaning if you want to delete an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to delete the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains a "?" character for the primary key value will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param primaryKey  The primary key matching the record to be deleted.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int deleteByPrimaryKey(Object objectMappingKey, Object primaryKey) throws PersistenceException{
        Connection connection = getConnection();
        try{
            return deleteByPrimaryKey(objectMappingKey, primaryKey, connection);
        } finally {
            close(connection);
        }
    }



    /**
     * Deletes the record from the database matching the given primary key, according to the
     * object mapping stored or generated by the given object mapping key.
     *
     * <br/><br/>
     * The provided connection will be used to delete the object in the database.
     * This can be useful when deleting an object as part of a transaction, or just
     * want to reuse the connection for several tasks. Remember to close the
     * connection yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the object to be deleted,
     * meaning if you want to delete an object of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to delete the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains a "?" character for the primary key value will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param primaryKey  The primary key matching the record to be deleted.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int deleteByPrimaryKey(Object objectMappingKey, Object primaryKey, Connection connection)
    throws PersistenceException{
        IObjectMapping  mapping = getObjectMapping(objectMappingKey);
        String          sql     = getSqlFromCache(mapping, getConfiguration().getDeleteSqlCache());

        if(sql == null){
            sql = getSqlGenerator().generateDeleteStatement(mapping);
            storeSqlInCache(mapping, getConfiguration().getDeleteSqlCache(), sql);
        }

        return getObjectWriter().deleteByPrimaryKey(mapping, primaryKey, sql, connection);
    }


    /**
     * Deletes the records from the database coresponding to the given primaryKeys, according to
     * the object mapping stored or generated by the given object mapping key. This method
     * uses JDBC batch updates to do the job, meaning the delete statements are batched up
     * and sent to the database in one go.
     *
     * <br/><br/>
     * A connection to the database will be obtained from the getConnection() method of this
     * class.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be delete,
     * meaning if you want to delete objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to delete the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains a "?" character for the primary key value will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param primaryKeys  The collection containing the primary keys of the records to be deleted.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int[] deleteByPrimaryKeysBatch(Object objectMappingKey, Collection primaryKeys) throws PersistenceException{
        Connection connection = getConnection();
        try{
            return deleteByPrimaryKeysBatch(objectMappingKey, primaryKeys, connection);
        } finally {
            close(connection);
        }
    }

    /**
     * Deletes the records from the database coresponding to the given primaryKeys, according to
     * the object mapping stored or generated by the given object mapping key. This method
     * uses JDBC batch updates to do the job, meaning the delete statements are batched up
     * and sent to the database in one go.
     *
     * <br/><br/>
     * The provided connection will be used to delete the objects in the database.
     * This can be useful when deleting objects as part of a transaction, or just
     * want to reuse the connection for several tasks. Remember to close the
     * connection yourself when you are done with it.
     *
     * <br/><br/>
     * If no object mapping is stored by the given object mapping key, a new object mapping
     * will be attempted generated and stored by that object mapping key. An object mapping
     * can only be generated automatically if the method key is either a </code>Class</code>
     * instance, or a <code>com.jenkov.mrpersister.impl.method.ObjectMappingKey</code> instance
     * with a <code>Class</code> instance set
     * (calling ObjectMappingKey's setObjectClass(Class theClass) method).
     *
     * <br/><br/>
     * The <code>Class</code> instance should be the class of the objects to be delete,
     * meaning if you want to delete objects of class <code>Employee</code> the
     * <code>Class</code> instance should be that found at <code>Employee.class</code>.
     *
     * <br/><br/>
     * The SQL needed to delete the record will be generated automatically based on the object
     * mapping, and executed using a <code>PreparedStatement</code>.
     * The SQL string contains a "?" character for the primary key value will be cached for later
     * use to avoid the SQL generation overhead.
     *
     * @param objectMappingKey  The object mapping key by which the object mapping to be used is stored
     *                    in the object mapping cache, in the persistence configuration used by this
     *                    instance of the DAO class.
     * @param primaryKeys The collection containing the primary keys of the records to be deleted.
     * @param connection  The database connection to use for the operation.
     * @return            The number of records affected by this delete action, as returned by
     *                    <code>PreparedStatement.executeUpdate()</code>.
     * @throws PersistenceException If anything goes wrong during the delete, if no persistence
     *                    configuration is set, if the persistence configuration contains
     *                    no object writer, or if no object mapping could be found nor generated
     *                    from the given object mapping key.
     */
    protected int[] deleteByPrimaryKeysBatch(Object objectMappingKey, Collection primaryKeys, 
                                             Connection connection) throws PersistenceException{
        IObjectMapping  mapping = getObjectMapping(objectMappingKey);
        String          sql     = getSqlFromCache(mapping, getConfiguration().getDeleteSqlCache());

        if(sql == null){
            sql = getSqlGenerator().generateDeleteStatement(mapping);
            storeSqlInCache(mapping, getConfiguration().getDeleteSqlCache(), sql);
        }

        return getObjectWriter().deleteByPrimaryKeysBatch(mapping, primaryKeys, sql, connection);
    }

}
