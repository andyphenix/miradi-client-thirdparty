/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



package com.jenkov.mrpersister.impl;

import com.jenkov.mrpersister.itf.*;
import com.jenkov.mrpersister.itf.mapping.IObjectMapper;
import com.jenkov.mrpersister.itf.mapping.IObjectMappingCache;
import com.jenkov.mrpersister.itf.mapping.ICustomObjectMapper;
import com.jenkov.mrpersister.impl.mapping.ObjectMapper;
import com.jenkov.mrpersister.impl.mapping.ObjectMappingCache;
import com.jenkov.mrpersister.MrPersister;

/**
 * Created by IntelliJ IDEA.
 * User: Administrator
 * Date: 16-02-2004
 * Time: 15:41:02
 * To change this template use File | Settings | File Templates.
 */
public class PersistenceConfiguration implements IPersistenceConfiguration{


    protected Object                configurationKey = null;

    protected IObjectReader         reader       = new ObjectReader();
    protected IObjectWriter         writer       = new ObjectWriter();
    protected IObjectMapper         mapper       = new ObjectMapper();
    protected IObjectMappingCache   mappingCache = new ObjectMappingCache();
    protected ICustomObjectMapper   customObjectMapper = null;

    protected ISqlGenerator         sqlGenerator                = new SqlGenerator();
    protected ISqlCache             readByPrimaryKeySqlCache    = new SqlCache();
    protected ISqlCache             insertSqlCache              = new SqlCache();
    protected ISqlCache             updateSqlCache              = new SqlCache();
    protected ISqlCache             deleteSqlCache              = new SqlCache();

    protected Database              database                    = null;

    public PersistenceConfiguration(){
        this.database = Database.DEFAULT;
    }

    public PersistenceConfiguration(Database database){
        this.database = database;
    }

    public Database getDatabase() {
        return this.database;
    }

    public void setDatabase(Database database) {
        this.database = database;
    }

    public Object getConfigurationKey() {
        return configurationKey;
    }

    public void setConfigurationKey(Object configurationKey) {
        this.configurationKey = configurationKey;
    }

    public void update() {
        MrPersister.setConfiguration(getConfigurationKey(), this);
    }

    public IObjectMapper getObjectMapper() {
        return this.mapper;
    }

    public void setObjectMapper(IObjectMapper mapper) {
        this.mapper = mapper;
    }

    public ICustomObjectMapper getCustomObjectMapper() {
        return customObjectMapper;
    }

    public void setCustomObjectMapper(ICustomObjectMapper customObjectMapper) {
        this.customObjectMapper = customObjectMapper;
    }

    public IObjectMappingCache getObjectMappingCache() {
        return this.mappingCache;
    }

    public void setObjectMappingCache(IObjectMappingCache cache) {
        this.mappingCache = cache;
    }

    public IObjectCache getObjectCache() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void setObjectCache(IObjectCache cache) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public IObjectReader getObjectReader() {
        return this.reader;
    }

    public void setObjectReader(IObjectReader reader) {
        this.reader = reader;
    }

    public IObjectWriter getObjectWriter() {
        return this.writer;
    }

    public void setObjectWriter(IObjectWriter writer) {
        this.writer = writer;
    }

    public ISqlGenerator getSqlGenerator() {
        return this.sqlGenerator;
    }

    public void setSqlGenerator(ISqlGenerator generator) {
        this.sqlGenerator = generator;
    }


    public ISqlCache getInsertSqlCache() {
        return this.insertSqlCache;
    }

    public void setInsertSqlCache(ISqlCache cache) {
        this.insertSqlCache = cache;
    }

    public ISqlCache getUpdateSqlCache() {
        return this.updateSqlCache;
    }

    public void setUpdateSqlCache(ISqlCache cache) {
        this.updateSqlCache = cache;
    }

    public ISqlCache getDeleteSqlCache() {
        return this.deleteSqlCache;
    }

    public void setDeleteSqlCache(ISqlCache cache) {
        this.deleteSqlCache = cache;
    }

    public ISqlCache getReadByPrimaryKeySqlCache() {
        return readByPrimaryKeySqlCache;
    }

    public void setReadByPrimaryKeySqlCache(ISqlCache readByPrimaryKeySqlCache) {
        this.readByPrimaryKeySqlCache = readByPrimaryKeySqlCache;
    }


}
