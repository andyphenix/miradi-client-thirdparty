/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



package com.jenkov.mrpersister.impl;

import com.jenkov.mrpersister.itf.IObjectWriter;
import com.jenkov.mrpersister.itf.PersistenceException;
import com.jenkov.mrpersister.itf.mapping.IGetterMapping;
import com.jenkov.mrpersister.itf.mapping.IKeyValue;
import com.jenkov.mrpersister.itf.mapping.IObjectMapping;
import com.jenkov.mrpersister.util.JdbcUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Iterator;

/**
 * @author Jakob Jenkov,  Jenkov Development
 */
public class ObjectWriter implements IObjectWriter{


    public int insert(IObjectMapping mapping, Object object, String sql, Connection connection) throws PersistenceException {
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            insertObjectFieldsInStatement(mapping, object, preparedStatement);
            return preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new PersistenceException("Error inserting object into database. Object was: (" +
                    object.toString() + ")\nSql: " + sql, e);
        } finally {
            JdbcUtil.close(preparedStatement);
        }
    }

    public int[] insertBatch(IObjectMapping mapping, Collection objects, String sql, Connection connection) throws PersistenceException {
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            Iterator iterator = objects.iterator();
            while(iterator.hasNext()){
                Object object = iterator.next();
                insertObjectFieldsInStatement(mapping, object, preparedStatement);
                preparedStatement.addBatch();
            }
            return preparedStatement.executeBatch();
        } catch (SQLException e) {
            throw new PersistenceException("Error batch inserting objects in database. Objects were: (" +
                    objects.toString() + ")\nSql: " + sql, e);
        } finally {
            JdbcUtil.close(preparedStatement);
        }
    }


    public int update(IObjectMapping mapping, Object object, String sql, Connection connection) throws PersistenceException {
         PreparedStatement preparedStatement = null;
         try {
             preparedStatement = connection.prepareStatement(sql);
             int parameterCount = insertObjectFieldsInStatement(mapping, object, preparedStatement);
             insertPrimaryKeyFromObject(mapping, object, preparedStatement, parameterCount);
             return preparedStatement.executeUpdate();
         } catch (SQLException e) {
             throw new PersistenceException("Error updating object in database. Object was: (" +
                     object.toString() + ")\nSql: " + sql, e);
         } finally {
             JdbcUtil.close(preparedStatement);
         }
     }


    public int update(IObjectMapping mapping, Object object, Object oldPrimaryKeyValue,
                      String sql, Connection connection) throws PersistenceException {
         PreparedStatement preparedStatement = null;
         try {
             preparedStatement = connection.prepareStatement(sql);
             int parameterCount = insertObjectFieldsInStatement(mapping, object, preparedStatement);
             insertPrimaryKeyValue(mapping, oldPrimaryKeyValue, preparedStatement, parameterCount);
             return preparedStatement.executeUpdate();
         } catch (SQLException e) {
             throw new PersistenceException("Error updating object in database. Object was: (" +
                     object.toString() + ")\nSql: " + sql, e);
         } finally {
             JdbcUtil.close(preparedStatement);
         }
     }


    public int[] updateBatch(IObjectMapping mapping, Collection objects, String sql, Connection connection) throws PersistenceException {
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            Iterator iterator = objects.iterator();
            while(iterator.hasNext()){
                Object object = iterator.next();
                int parameterCount = insertObjectFieldsInStatement(mapping, object, preparedStatement);
                insertPrimaryKeyFromObject(mapping, object, preparedStatement, parameterCount);
                preparedStatement.addBatch();
            }
            return preparedStatement.executeBatch();
        } catch (SQLException e) {
            throw new PersistenceException("Error batch updating objects in database. Objects were: (" +
                    objects.toString() + ")\nSql: " + sql, e);
        } finally {
            JdbcUtil.close(preparedStatement);
        }
    }


    public int[] updateBatch(IObjectMapping mapping, Collection objects, Collection oldPrimaryKeys,
            String sql, Connection connection) throws PersistenceException {
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            Iterator objectIterator        = objects.iterator();
            Iterator oldPrimaryKeyIterator = oldPrimaryKeys.iterator();

            while(objectIterator.hasNext()){
                Object object        = objectIterator.next();
                Object oldPrimaryKey = oldPrimaryKeyIterator.next();
                int parameterCount = insertObjectFieldsInStatement(mapping, object, preparedStatement);
                insertPrimaryKeyValue(mapping, oldPrimaryKey, preparedStatement, parameterCount);
                preparedStatement.addBatch();
            }
            return preparedStatement.executeBatch();
        } catch (SQLException e) {
            throw new PersistenceException("Error batch updating objects in database. Objects were: (" +
                    objects.toString() + ")\nOld Primary Keys were: (" + oldPrimaryKeys + ")" +
                    "\nSql: " + sql, e);
        } finally {
            JdbcUtil.close(preparedStatement);
        }
    }


    public int delete(IObjectMapping mapping, Object object, String sql, Connection connection) throws PersistenceException {
         PreparedStatement preparedStatement = null;
         try{
             preparedStatement = connection.prepareStatement(sql);
             insertPrimaryKeyFromObject(mapping, object, preparedStatement, 1);
             return preparedStatement.executeUpdate();
         } catch(SQLException e){
             throw new PersistenceException("Error deleting object: " + object + ", using method:\n" + mapping);
         } finally {
             JdbcUtil.close(preparedStatement);
         }
     }

    public int[] deleteBatch(IObjectMapping mapping, Collection objects, String sql, Connection connection) throws PersistenceException {
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            Iterator iterator = objects.iterator();
            while(iterator.hasNext()){
                Object object = iterator.next();
                insertPrimaryKeyFromObject(mapping, object, preparedStatement, 1);
                preparedStatement.addBatch();
            }
            return preparedStatement.executeBatch();
        } catch (SQLException e) {
            throw new PersistenceException("Error batch deleting objects in database. Objects were: (" +
                    objects.toString() + ")\nSql: " + sql, e);
        } finally {
            JdbcUtil.close(preparedStatement);
        }
    }


    public int deleteByPrimaryKey(IObjectMapping mapping, Object primaryKey, String sql, Connection connection) throws PersistenceException {
        PreparedStatement preparedStatement = null;
        try{
            preparedStatement = connection.prepareStatement(sql);
            insertPrimaryKeyValue(mapping, primaryKey, preparedStatement, 1);
            return preparedStatement.executeUpdate();
        } catch(SQLException e){
            throw new PersistenceException("Error deleting object by primary key: " + primaryKey + ", using method:\n" + mapping);
        } finally {
            JdbcUtil.close(preparedStatement);
        }
    }


    public int[] deleteByPrimaryKeysBatch(IObjectMapping mapping, Collection primaryKeys, String sql, Connection connection) throws PersistenceException {
        PreparedStatement preparedStatement = null;
        try {
            preparedStatement = connection.prepareStatement(sql);
            Iterator iterator = primaryKeys.iterator();
            while(iterator.hasNext()){
                Object primaryKey = iterator.next();
                insertPrimaryKeyValue(mapping, primaryKey, preparedStatement, 1);
                preparedStatement.addBatch();
            }
            return preparedStatement.executeBatch();
        } catch (SQLException e) {
            throw new PersistenceException("Error batch deleting objects in database. Primary keys were: (" +
                    primaryKeys.toString() + ")\nSql: " + sql, e);
        } finally {
            JdbcUtil.close(preparedStatement);
        }
    }


     private int insertObjectFieldsInStatement(IObjectMapping mapping, Object object, PreparedStatement preparedStatement)
     throws PersistenceException {
         Iterator iterator = mapping.getGetterMappings().iterator();
         int i=1;
         while(iterator.hasNext()){
             IGetterMapping fieldMapping = (IGetterMapping) iterator.next();
             if(fieldMapping.isTableMapped() && !fieldMapping.isAutoGenerated()){
                 fieldMapping.insertValueFromObject(object, preparedStatement, i);
                 i++;
             }
         }
         return i;
     }


    private void insertPrimaryKeyFromObject(IObjectMapping mapping, Object object, PreparedStatement preparedStatement, int parameterCount) throws PersistenceException {
        Iterator iterator = mapping.getPrimaryKey().getColumns().iterator();
        while(iterator.hasNext()){
            mapping.getGetterMapping((String) iterator.next())
                    .insertValueFromObject(object, preparedStatement, parameterCount++);
        }
    }


    private void insertPrimaryKeyValue(IObjectMapping mapping, Object oldPrimaryKeyValue, PreparedStatement preparedStatement, int parameterCount) throws PersistenceException {
        IKeyValue value = null;
        if(oldPrimaryKeyValue instanceof IKeyValue){
            value = (IKeyValue) oldPrimaryKeyValue;
        } else {
            value = mapping.getPrimaryKey().toKeyValue(oldPrimaryKeyValue);
        }
        Iterator iterator = mapping.getPrimaryKey().getColumns().iterator();
        while(iterator.hasNext()){
            String column = (String) iterator.next();
            mapping.getGetterMapping(column)
                    .insertObject(value.getColumnValue(column), preparedStatement, parameterCount++);
        }
    }



}
