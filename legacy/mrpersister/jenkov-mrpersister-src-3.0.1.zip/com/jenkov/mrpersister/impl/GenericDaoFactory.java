/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



package com.jenkov.mrpersister.impl;

import com.jenkov.mrpersister.PersistenceManager;
import com.jenkov.mrpersister.itf.IGenericDao;
import com.jenkov.mrpersister.itf.IGenericDaoFactory;
import com.jenkov.mrpersister.itf.IPersistenceConfiguration;

import java.sql.Connection;

/**
 * @author Jakob Jenkov - Copyright 2005 Jenkov Development
 */
public class GenericDaoFactory implements IGenericDaoFactory{

    protected PersistenceManager persistenceManager = null;

    public GenericDaoFactory() {
    }

    public GenericDaoFactory(PersistenceManager persistenceManager) {
        this.persistenceManager = persistenceManager;
    }

    public IGenericDao createDao(Connection connection) {
        return new GenericDao(connection);
    }

    public IGenericDao createDao(Connection connection, IPersistenceConfiguration configuration) {
        return new GenericDao(connection, configuration);
    }

    public IGenericDao createDao(Connection connection, Object configKey) {
        return new GenericDao(connection,
                this.persistenceManager.getConfigurationFactory().getOrCreateConfiguration(configKey));
    }
}
