/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



package com.jenkov.mrpersister.impl;

import com.jenkov.mrpersister.itf.IPersistenceConfigurationFactory;
import com.jenkov.mrpersister.itf.IPersistenceConfiguration;
import com.jenkov.mrpersister.itf.Database;
import com.jenkov.mrpersister.impl.mapping.HsqldbPrimaryKeyDeterminer;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Jakob Jenkov - Copyright 2005 Jenkov Development
 */
public class PersistenceConfigurationFactory implements IPersistenceConfigurationFactory{

    protected Map configurations  = new HashMap();

    public IPersistenceConfiguration createConfiguration() {
        return createConfiguration(Database.DEFAULT);
    }

    public IPersistenceConfiguration createConfiguration(Database database) {
        if(Database.HSQLDB.equals(database)) return hsqldbConfiguration();
        return new PersistenceConfiguration();
    }

    public synchronized IPersistenceConfiguration getOrCreateConfiguration(Object configurationKey) {
        IPersistenceConfiguration configuration = getConfiguration(configurationKey);
        if(configuration == null){
            configuration = createConfiguration();
            storeConfiguration(configurationKey, configuration);
        }
        return configuration;
    }

    public synchronized IPersistenceConfiguration getOrCreateConfiguration(Object configurationKey, Database database) {
        IPersistenceConfiguration configuration = getConfiguration(configurationKey);
        if(configuration == null){
            configuration = createConfiguration(database);
            storeConfiguration(configurationKey, configuration);
        }
        return configuration;
    }

    public synchronized IPersistenceConfiguration getConfiguration(Object configurationKey) {
        return (IPersistenceConfiguration) this.configurations.get(configurationKey);
    }

    public synchronized void storeConfiguration(Object configurationKey, IPersistenceConfiguration configuration) {
        this.configurations.put(configurationKey, configuration);
    }

    public synchronized void removeConfiguration(Object configurationKey) {
        this.configurations.remove(configurationKey);
    }


    private IPersistenceConfiguration hsqldbConfiguration() {
        IPersistenceConfiguration configuration = new PersistenceConfiguration(Database.HSQLDB);
        configuration.getObjectMapper().setDbPrimaryKeyDeterminer(new HsqldbPrimaryKeyDeterminer());
        return configuration;
    }


}
