/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



/**
 * User: Administrator
 */
package com.jenkov.mrpersister.impl.mapping.method;

import com.jenkov.mrpersister.itf.mapping.IGetterMapping;
import com.jenkov.mrpersister.itf.mapping.IMethodMapping;
import com.jenkov.mrpersister.itf.mapping.ISetterMapping;
import com.jenkov.mrpersister.util.ClassUtil;

import java.lang.reflect.Method;

public class MethodMapping implements IMethodMapping, Comparable {

    //protected IObjectMapping objectMapping  = null;
    protected String         columnName = null;
    protected Method         objectMethod         = null;

    protected boolean        isPrimaryKey   = false;
    //protected boolean        isForeignKey   = false;
    protected boolean        isTableMapped  = false;

    //protected String         referencesTable = null;

    public String getColumnName() {
        return this.columnName;
    }

    public void setColumnName(String fieldName) {
        this.columnName = fieldName;
    }

    public Method getObjectMethod() {
        return this.objectMethod;
    }

    public void setObjectMethod(Method member) {
        this.objectMethod = member;
    }

    public boolean isPrimaryKey() {
        return this.isPrimaryKey;
    }

    public void setPrimaryKey(boolean isPrimaryKey) {
        this.isPrimaryKey = isPrimaryKey;
    }

    /*
    public boolean isForeignKey() {
        return this.isForeignKey;
    }

    public void setForeignKey(boolean isForeignKey) {
        this.isForeignKey = isForeignKey;
    }*/

    public boolean isTableMapped() {
        return this.isTableMapped;
    }

    public void setTableMapped(boolean isTableMapped){
        this.isTableMapped = isTableMapped;
    }


/*
    public String referencesTable() {
        return this.referencesTable;
    }
*/






   public boolean equals(Object o){
        if(! (o instanceof IMethodMapping)) return false;
        IMethodMapping fieldMapping = (IMethodMapping) o;

        if(!ClassUtil.areEqual(getObjectMethod()  , fieldMapping.getObjectMethod())) return false;
        if(!ClassUtil.areEqual(getColumnName()   , fieldMapping.getColumnName())) return false;

        //if(isForeignKey() != fieldMapping.isForeignKey()) return false;
        if(isPrimaryKey() != fieldMapping.isPrimaryKey()) return false;
        if(isTableMapped() != fieldMapping.isTableMapped()) return false;

        return true;
    }

    public int hashCode(){
        if(getColumnName() != null)  return getColumnName().hashCode();
        if(getObjectMethod() != null) return getObjectMethod().getName().hashCode();
        return super.hashCode();
    }


    public String toString(){
        StringBuffer buffer = new StringBuffer();
        buffer.append(getObjectMethod().getName());
        if(this instanceof IGetterMapping){
            buffer.append("  -->  ");
        } else if(this instanceof ISetterMapping){
            buffer.append("  <--  ");
        } else {
            buffer.append("  <-?->  ");
        }
        if(getColumnName() != null){
            buffer.append(getColumnName());
        } else {
            buffer.append("[no method]");
        }

        buffer.append("     (");
        buffer.append(ClassUtil.classNameWithoutPackage(getClass()));
        buffer.append(')');
        return buffer.toString();
    }


    public int compareTo(Object o) {
        IMethodMapping fieldMapping = (IMethodMapping) o;

        if(this instanceof IGetterMapping && ! (fieldMapping instanceof IGetterMapping)) return -1;
        if(this instanceof ISetterMapping && ! (fieldMapping instanceof ISetterMapping)) return 1;

        if(isTableMapped() && !fieldMapping.isTableMapped()) return -1;
        if(!isTableMapped() && fieldMapping.isTableMapped()) return 1;

        if(isPrimaryKey() && !fieldMapping.isPrimaryKey()) return -1;
        if(!isPrimaryKey() && fieldMapping.isPrimaryKey()) return 1;

        int comparison = ClassUtil.compare(getObjectMethod(), fieldMapping.getObjectMethod());
        if(comparison != 0) return comparison;

        comparison = ClassUtil.compare(getColumnName(), fieldMapping.getColumnName());
        if(comparison != 0) return comparison;

        return 0;
    }
}
