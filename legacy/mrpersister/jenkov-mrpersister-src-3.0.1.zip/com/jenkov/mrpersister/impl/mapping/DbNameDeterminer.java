/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



/**
 * User: Administrator
 */
package com.jenkov.mrpersister.impl.mapping;

import com.jenkov.mrpersister.itf.mapping.IDbNameDeterminer;
import com.jenkov.mrpersister.itf.PersistenceException;
import com.jenkov.mrpersister.util.JdbcUtil;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

public class DbNameDeterminer implements IDbNameDeterminer {

    protected Map tableColumnSets = new HashMap();

    public void init(){
        this.tableColumnSets.clear();
    }


    public String determineColumnName(Collection names, String tableName, Connection connection)
    throws PersistenceException {

        Set fieldNames  = new HashSet();
        Set columnNames = null;
        Iterator fieldIterator = names.iterator();

        try {
            columnNames = getColumns(tableName, connection);

            while(fieldIterator.hasNext()){
                String name = (String) fieldIterator.next();
                if(columnNames.contains(name)){
                    fieldNames.add(name);
                }
            }
        } catch (SQLException e) {
            throw new PersistenceException("Could not read database meta data for table " + tableName, e);
        }

        if(fieldNames.size() == 1) return (String) fieldNames.iterator().next();
        if(fieldNames.size() > 1){
            throw new PersistenceException("More than one method in table " + tableName
                +" matched the guessed names: " + names.toString()
                +". \nMatching fields were: " + fieldNames.toString());
        }
        return null;
    }


    public String determineTableName(Collection names, Connection connection)
    throws PersistenceException{
        return determineTableName(names, null, connection);
    }


    public String determineTableName(Collection names, String databaseName, Connection connection)
    throws PersistenceException {
        Set tableNames = new HashSet();
        try {
            Iterator nameIterator = names.iterator();
            while(nameIterator.hasNext()){
                String name = (String) nameIterator.next();
                ResultSet result = connection.getMetaData().getTables(databaseName, null, name, null );
                while(result.next()){
                    if(name.equals(result.getString(3))) tableNames.add(name);
                }
            }
        } catch (SQLException e) {
            throw new PersistenceException("Could not read meta data for database " + databaseName, e);
        }

        if(tableNames.size() == 1) return (String) tableNames.iterator().next();
        if(tableNames.size() > 1){
            throw new PersistenceException("More than one table in database " + databaseName
                +" matched the guessed names: " + names.toString()
                +". \nMatching tables were: " + tableNames.toString());
        }
        throw new PersistenceException("No tables in database " + databaseName
            + " matched the guessed names: " + names.toString());
    }

    private synchronized Set getColumns(String tableName, Connection connection) throws SQLException, PersistenceException {
        Set       columns = (Set) this.tableColumnSets.get(tableName);
        if(columns != null){
            return columns;
        }
        columns = new HashSet();

        ResultSet result  = null;
        try {
            result = connection.getMetaData().getColumns(null, null,  tableName, null);
            while(result.next()){
                if(result.getString(4) != null){
                    columns.add(result.getString(4));
                }
            }
        } finally {
            JdbcUtil.close(result);
        }
        this.tableColumnSets.put(tableName, columns);
        return columns;
    }

}
