/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



/**
 * User: Administrator
 */
package com.jenkov.mrpersister.impl.mapping;

import com.jenkov.mrpersister.itf.PersistenceException;
import com.jenkov.mrpersister.itf.mapping.*;
import com.jenkov.mrpersister.util.CollectionUtils;
import com.jenkov.mrpersister.util.ClassUtil;

import java.lang.reflect.Method;
import java.util.*;

public class ObjectMapping implements IObjectMapping{

    protected String        tableName             = null;
    protected String        primaryKeyColumnName = null;
    protected Class         objectType            = null;
    protected Collection    getterMappingSet = new TreeSet();
    protected Collection    setterMappingSet = new TreeSet();
    protected Map           getterMappingMap = new HashMap();
    protected Map           setterMappingMap = new HashMap();
    protected IKey          primaryKey       = new Key();

    public String getTableName() {
        return this.tableName;
    }

    public void setTableName(String tableName){
        this.tableName = tableName;
    }

    public IKey getPrimaryKey() {
        return primaryKey;
    }

    public void setPrimaryKey(IKey primaryKey) {
        this.primaryKey = primaryKey;
    }

    // todo remove this method from v. 4.0.0
    public String getPrimaryKeyColumnName() {
        return primaryKeyColumnName;
    }

    // todo remove this method from v. 4.0.0
    public void setPrimaryKeyColumnName(String primaryKeyColumnName) {
        this.primaryKeyColumnName = primaryKeyColumnName;
        if(primaryKeyColumnName != null){
            this.primaryKey.addColumn(primaryKeyColumnName);
        } else {
           this.primaryKey.getColumns().clear();
        }
    }


    public Class getObjectClass() {
        return this.objectType;
    }

    public void setObjectClass(Class objectType) {
        this.objectType = objectType;
    }

    public void addGetterMapping(IGetterMapping mapping) throws PersistenceException{
        validateMethodMapping(mapping);

        this.getterMappingSet.add(mapping);
        this.getterMappingMap.put(mapping.getColumnName(), mapping);
        this.getterMappingMap.put(mapping.getObjectMethod(), mapping);
    }

    public void addSetterMapping(ISetterMapping mapping) throws PersistenceException{
        validateMethodMapping(mapping);

        this.setterMappingSet.add(mapping);
        this.setterMappingMap.put(mapping.getColumnName(), mapping);
        this.setterMappingMap.put(mapping.getObjectMethod(), mapping);
    }

    protected void validateMethodMapping(IMethodMapping mapping) throws PersistenceException {
        if(mapping == null){
            throw new PersistenceException("The method method was null");
        }
        if(mapping.getColumnName() == null || mapping.getObjectMethod() == null){
            throw new PersistenceException("The getter method method must contain " +
                    "both database method name and an object method before you can add it to an object method.");
        }
    }


    public void removeGetterMapping(String columnName) {
        IGetterMapping fieldMapping = getGetterMapping(columnName);
        if(fieldMapping == null) return;
        removeGetterFieldMapping(fieldMapping);
    }

    public void removeGetterFieldMapping(IGetterMapping getterMapping) {
        this.getterMappingMap.remove(getterMapping.getColumnName());
        this.getterMappingMap.remove(getterMapping.getObjectMethod());
        this.getterMappingSet.remove(getterMapping);
    }

    public void removeGetterMapping(Method method) {
        IGetterMapping fieldMapping = getGetterMapping(method);
        if(fieldMapping == null) return;
        removeGetterFieldMapping(fieldMapping);
    }

    public void removeSetterMapping(String columnName) {
        ISetterMapping fieldMapping = getSetterMapping(columnName);
        if(fieldMapping == null) return;
        removeSetterFieldMapping(fieldMapping);
    }

    public void removeSetterMapping(Method method) {
        ISetterMapping fieldMapping = getSetterMapping(method);
        if(fieldMapping == null) return;
        removeSetterFieldMapping(fieldMapping);
    }

    public void removeSetterFieldMapping(ISetterMapping setterMapping) {
        this.setterMappingMap.remove(setterMapping.getColumnName());
        this.setterMappingMap.remove(setterMapping.getObjectMethod());
        this.setterMappingSet.remove(setterMapping);
    }

    public Collection getGetterMappings() {
        return this.getterMappingSet;
    }

    public Collection getSetterMappings() {
        return this.setterMappingSet;
    }


    public IGetterMapping getPrimaryKeyGetterMapping() {
        return getGetterMapping(getPrimaryKeyColumnName());
    }

    public ISetterMapping getPrimaryKeySetterMapping() {
        return getSetterMapping(getPrimaryKeyColumnName());
    }


    public IGetterMapping getGetterMapping(String columnName) {
        return (IGetterMapping) this.getterMappingMap.get(columnName);
    }

    public IGetterMapping getGetterMapping(Method objectMethod) {
        return (IGetterMapping) this.getterMappingMap.get(objectMethod);
    }

    public ISetterMapping getSetterMapping(String columnName) {
        return (ISetterMapping) this.setterMappingMap.get(columnName);
    }

    public ISetterMapping getSetterMapping(Method objectMethod) {
        return (ISetterMapping) this.setterMappingMap.get(objectMethod);
    }


    public String toString(){
        StringBuffer buffer = new StringBuffer();

        if(getObjectClass() != null){
            buffer.append("Class: ");
            buffer.append(getObjectClass().getName());
            buffer.append("\n");
        } else {
            buffer.append("Class: null\n");
        }
        buffer.append("Table: ");
        buffer.append(getTableName());
        buffer.append("\n-------------------\n");
                         

        int maxLength = getMaxGetterSetterNameLength();

        appendMethodMappings(buffer, getGetterMappings(), "-->", maxLength);
        appendMethodMappings(buffer, getSetterMappings(), "<--", maxLength);

        return buffer.toString();
    }

    private int getMaxGetterSetterNameLength() {
        int maxLength = 0;

        Iterator iterator = getGetterMappings().iterator();
        while(iterator.hasNext()){
            IMethodMapping fieldMapping = (IMethodMapping) iterator.next();
            if(maxLength < fieldMapping.getObjectMethod().getName().length()){
                maxLength = fieldMapping.getObjectMethod().getName().length();
            }
        }

        iterator = getSetterMappings().iterator();
        while(iterator.hasNext()){
            IMethodMapping fieldMapping = (IMethodMapping) iterator.next();
            if(maxLength < fieldMapping.getObjectMethod().getName().length()){
                maxLength = fieldMapping.getObjectMethod().getName().length();
            }
        }
        return maxLength;
    }


    protected void appendMethodMappings(StringBuffer buffer, Collection mappings, String direction, int length){
        List mappingList = CollectionUtils.toList(mappings);
        Collections.sort(mappingList);
        Iterator iterator = mappingList.iterator();
        while(iterator.hasNext()){
            IMethodMapping fieldMapping = (IMethodMapping) iterator.next();
            //buffer.append("       ");
            buffer.append(fieldMapping.getObjectMethod().getName());

            int spaces = length - fieldMapping.getObjectMethod().getName().length() + 1;
            for(int i=0; i<spaces; i++){
                buffer.append(" ");
            }
            buffer.append(direction);
            buffer.append(" ");
            buffer.append(fieldMapping.getColumnName());
            buffer.append("\n");
        }
    }

    public boolean equals(Object o){
        if(! (o instanceof IObjectMapping))  return false;
        IObjectMapping mapping = (IObjectMapping) o;

        if(!ClassUtil.areEqual(this.getObjectClass(), mapping.getObjectClass())){
            return false;
        }
        if(!ClassUtil.areEqual(this.getTableName(), mapping.getTableName())){
            return false;
        }
        if(!ClassUtil.areEqual(this.getPrimaryKey(), mapping.getPrimaryKey())){
            return false;
        }

        //test getter method mappings
        if(getGetterMappings().size() != mapping.getGetterMappings().size()){
            return false;
        }

        Iterator getters = getGetterMappings().iterator();
        while(getters.hasNext()){
            IGetterMapping fieldMapping = (IGetterMapping) getters.next();
            if(!ClassUtil.areEqual(fieldMapping, mapping.getGetterMapping( fieldMapping.getColumnName()))){
                return false;
            }
        }

        //test setter method mappings
        if(getSetterMappings().size() != mapping.getSetterMappings().size()){
            return false;
        }

        Iterator setters = this.setterMappingSet.iterator();
        while(setters.hasNext()){
            ISetterMapping fieldMapping = (ISetterMapping) setters.next();
            if(!ClassUtil.areEqual(fieldMapping, mapping.getSetterMapping( fieldMapping.getColumnName()))){
                return false;
            }
        }

        return true;
    }

    public int hashCode() {
        if(getObjectClass() != null){
            return getObjectClass().hashCode();
        }

        return super.hashCode();
    }

}
