/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



package com.jenkov.mrpersister.impl.mapping;

import com.jenkov.mrpersister.itf.mapping.IKeyValue;

import java.util.Map;
import java.util.TreeMap;
import java.util.Iterator;

/**
 * @author Jakob Jenkov - Copyright 2005 Jenkov Development
 */
public class KeyValue implements IKeyValue{

    protected Map columnValues = new TreeMap();

    public void addColumnValue(String column, Object value) {
        this.columnValues.put(column, value);
    }

    public void removeColumnValue(String column) {
        this.columnValues.remove(column);
    }

    public Object getColumnValue(String column) {
        return columnValues.get(column);
    }

    public Map getColumnValues() {
        return this.columnValues;
    }

    public String toString() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("(");

        Iterator iterator = columnValues.keySet().iterator();
        while(iterator.hasNext()){
            String column = (String) iterator.next();
            buffer.append(column);
            buffer.append(" = ");
            buffer.append(getColumnValue(column));
            if(iterator.hasNext()){
                buffer.append(", ");
            }
        }

        buffer.append(")");

        return buffer.toString();
    }

}
