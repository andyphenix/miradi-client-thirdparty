/*
    Copyright 2004 Jenkov Development

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/



package com.jenkov.mrpersister.impl.mapping;

import com.jenkov.mrpersister.MrPersister;
import com.jenkov.mrpersister.itf.PersistenceException;
import com.jenkov.mrpersister.itf.mapping.*;
import com.jenkov.mrpersister.util.ClassUtil;

import java.lang.reflect.Method;
import java.sql.Connection;
import java.util.Collection;
import java.util.Iterator;

/**
 * @author Jakob Jenkov,  Jenkov Development
 */
public class ObjectMapper implements IObjectMapper{

    protected IDbNameGuesser    nameGuesser     = new DbNameGuesser();
    protected IDbNameDeterminer nameDeterminer  = new DbNameDeterminer();
//    protected IDbNameDeterminer nameDeterminerOld  = new DbNameDeterminerOld();
    protected IDbPrimaryKeyDeterminer primaryKeyDeterminer = new DbPrimaryKeyDeterminer();

    public IDbPrimaryKeyDeterminer getDbPrimaryKeyDeterminer() {
        return this.primaryKeyDeterminer;
    }

    public void setDbPrimaryKeyDeterminer(IDbPrimaryKeyDeterminer primaryKeyDeterminer) {
        this.primaryKeyDeterminer = primaryKeyDeterminer;
    }

    public IDbNameGuesser getDbNameGuesser() {
        return this.nameGuesser;
    }

    public void setDbNameGuesser(IDbNameGuesser guesser) {
        this.nameGuesser = guesser;
    }

    public IDbNameDeterminer getDbNameDeterminer() {
        return this.nameDeterminer;
    }

    public void setDbNameDeterminer(IDbNameDeterminer nameDeterminer) {
        this.nameDeterminer = nameDeterminer;
    }


    public IObjectMapping mapToTable(Class objectClass, IObjectMapping objectMapping, Connection connection,
                                     String databaseName, String table) throws PersistenceException {

        return mapGettersToTable(
                objectClass,
                mapSettersToTable(objectClass, objectMapping, connection, databaseName, table),
                connection,
                databaseName,
                table);
    }

    public IObjectMapping mapGettersToTable(Class objectClass, IObjectMapping objectMapping, Connection connection, String databaseName, String table) throws PersistenceException {
        objectMapping  = assureValidObjectMapping(objectClass, objectMapping, connection, databaseName, table);

        Method[] methods = objectMapping.getObjectClass().getMethods();
        for(int i=0; i < methods.length; i++){
            if(!ClassUtil.isGetter(methods[i])) continue;
            if(methods[i].getName().equals("getClass")) continue;

            Collection possibleNames = this.nameGuesser.getPossibleColumnNames(methods[i]);
            String dbFieldName       = this.nameDeterminer.determineColumnName(possibleNames, objectMapping.getTableName(), connection);

            if(dbFieldName != null) {
                IGetterMapping fieldMapping = MrPersister.getObjectMappingFactory()
                        .createGetterMapping(methods[i], dbFieldName, true);
                objectMapping.addGetterMapping(fieldMapping);
            }
        }
        return objectMapping;
    }




    public IObjectMapping mapSettersToTable(Class objectClass, IObjectMapping objectMapping,
                                            Connection connection, String databaseName, String table) throws PersistenceException {
        objectMapping  = assureValidObjectMapping(objectClass, objectMapping, connection, databaseName, table);

        Method[] methods = objectMapping.getObjectClass().getMethods();
        for(int i=0; i < methods.length; i++){
            if(!ClassUtil.isSetter(methods[i])) continue;

            Collection possibleNames = this.nameGuesser.getPossibleColumnNames(methods[i]);
            String dbFieldName       = this.nameDeterminer.determineColumnName(possibleNames,
                                        objectMapping.getTableName(), connection);

            if(dbFieldName != null) {
                ISetterMapping fieldMapping = MrPersister.getObjectMappingFactory()
                        .createSetterMapping(methods[i], dbFieldName, true);
                objectMapping.addSetterMapping(fieldMapping);
            }
        }
        return objectMapping;  //To change body of implemented methods use File | Settings | File Templates.
    }



    public IObjectMapping mapSettersToSelf(Class persistentObjectClass, IObjectMapping objectMapping)
    throws PersistenceException{
        if(objectMapping == null){
            objectMapping = MrPersister.getObjectMappingFactory().createObjectMapping();
        }

        Method[] methods = persistentObjectClass.getMethods();

        for(int i=0; i < methods.length; i++){
            if(!ClassUtil.isSetter(methods[i])) continue;

            ISetterMapping fieldMapping =
                    MrPersister.getObjectMappingFactory().createSetterMapping(methods[i], methods[i].getName(), false);
            objectMapping.addSetterMapping((ISetterMapping) fieldMapping);
        }

        return objectMapping;
    }

    private IObjectMapping assureValidObjectMapping(Class objectClass, IObjectMapping objectMapping,
                                                    Connection connection, String databaseName, String table)
    throws PersistenceException{
        if(objectMapping == null){
            objectMapping = MrPersister.getObjectMappingFactory().createObjectMapping();
        }
        assureValidObjectClass          (objectMapping, objectClass);
        assureValidTableName            (objectMapping, table, connection);
        assureValidPrimaryKeyColumnName(objectMapping, databaseName, connection);

        return objectMapping;
    }


    private void assureValidTableName(IObjectMapping objectMapping, String table, Connection connection)
    throws PersistenceException {
        if(table == null && objectMapping.getTableName() != null){
            return;
        }
        if(table != null && objectMapping.getTableName() == null){
            objectMapping.setTableName(table);
            return;
        }
        if(table != null && objectMapping.getTableName() != null){
            if(!table.equals(objectMapping.getTableName())){
                throw new PersistenceException("Two different table names provided for object method for class " +
                        objectMapping.getObjectClass().getName() + ". Table name '" + table + "' passed as " +
                        "parameter doesn't match with table name '" + objectMapping.getTableName() +
                        "'  found in the provided object method");
            } else {
                return;
            }
        }

        table = this.nameDeterminer.determineTableName(
                this.nameGuesser.getPossibleTableNames(objectMapping.getObjectClass()),
                null,
                connection );
        if(table != null) {
            objectMapping.setTableName(table);
            return;
        }


        throw new PersistenceException("No table found matching class " + objectMapping.getObjectClass());
    }

    private void assureValidPrimaryKeyColumnName(IObjectMapping objectMapping, String databaseName, Connection connection) throws PersistenceException {
        if(objectMapping.getPrimaryKey().getTable() == null){
            objectMapping.setPrimaryKey(this.primaryKeyDeterminer
                    .getPrimaryKeyMapping(objectMapping.getTableName(), databaseName, connection));
        }
        // todo remove this primary key backward compatiblity call in v. 4.0.0
        assurePrimaryKeyBackwardCompatibility(objectMapping);
        /**
        if(objectMapping.getPrimaryKeyColumnName() == null){
            objectMapping.setPrimaryKeyColumnName(
                this.primaryKeyDeterminer.getPrimaryKeyColumnName(objectMapping.getTableName(), databaseName, connection));
        }*/
    }

    /**
     * This method assures that if anyone is / was using the old primary key mechanisms directly,
     * and not indirectly throught the AbstractDao, the primary key will still look sensible, and
     * can still be used.
     * todo Remove this primary key backward compatibility in v. 4.0.0
     * @param objectMapping The object mapping to assure still has the primary key denoted the
     * old fashioned way.
     */
    private void assurePrimaryKeyBackwardCompatibility(IObjectMapping objectMapping) {
        if(objectMapping.getPrimaryKey().getColumns().size() == 1){
            Iterator iterator = objectMapping.getPrimaryKey().getColumns().iterator();
            objectMapping.setPrimaryKeyColumnName((String) iterator.next());
        }
    }

    private void assureValidObjectClass(IObjectMapping mapping, Class persistentObjectClass) throws PersistenceException {
        if(persistentObjectClass == null && mapping.getObjectClass() == null){
            throw new PersistenceException("No class provided in either parameter or inside object method");
        }
        if(persistentObjectClass == null && mapping.getObjectClass() != null){
            return;
        }
        if(persistentObjectClass != null && mapping.getObjectClass() == null){
            mapping.setObjectClass(persistentObjectClass);
            return ;
        }

        if(!persistentObjectClass.equals(mapping.getObjectClass())){
            throw new PersistenceException("The object class passed as parameter ("
                    +  persistentObjectClass.getName()
                    +  ") and the object class found in "
                    +  "the provided object method ("
                    +  mapping.getObjectClass().getName()
                    +  ") did not match. They must be the same, or only one of them should be provided. "
                    +  "You can leave out either of them (set to null) and the one present will be used.");
        }
    }

}
